package com.qinnan.fram;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Toolkit;

import javax.swing.JComponent;
import javax.swing.JFrame;
public class dri {
	public static void main(String [] args){
		JFrame window=new JFrame("Nan Qin");
		Toolkit kitWindow=Toolkit.getDefaultToolkit();
		
		window.setSize(kitWindow.getScreenSize().width/3,kitWindow.getScreenSize().height/3 );
		Component widget=new Component(){
			public void  print(Graphics g){
				//Toolkit kitComponent=Toolkit.getDefaultToolkit();
				g.drawString("Hello",100, 100);
				g.drawRect(200,200,120,320);
			}
		};
		window.getContentPane().add(widget);
		window.setVisible(true);
		try{
			window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}catch(SecurityException e){
			e.printStackTrace();
		}
	}

}
