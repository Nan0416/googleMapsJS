package qinnan.callback.com;
// stupid .....
// bad definition of interface.
public class Test {
	public static void main(String [] args){
		show_pic_A x = new show_pic_A();
		x.picture();
	}

}

class xiangkuang {
	public void add(show_pic A){
		A._picture();
		System.out.println("Add xiangkuang.");
	}
}
interface show_pic{
	public void _picture();
}
class show_pic_A implements show_pic{

	@Override

	public void _picture() {
		System.out.println("Aurora.");
	}
	 
	public void picture(){
		xiangkuang x = new xiangkuang();
		x.add(this);
	}
	
}