package com.qinnan.database;

import java.awt.Image;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.imageio.ImageIO;

public class dri {
	public static void main(String [] args) throws SQLException, ClassNotFoundException, IOException{
		
		Class.forName("com.mysql.jdbc.Driver");
		String address="192.168.19.11";
		String databaseName="NanQin";
		String user="hatakusunoki";
		String password="QN1994qn";
		Connection conn=DriverManager.getConnection("jdbc:mysql://"+address+":3306/"+databaseName, user, password);
		Statement stat=conn.createStatement();
		//Scanner in=new Scanner(System.in);
		//in.next();
		ResultSet rs;
		//for(int i=0;i<1000;i++){
			//String sql="insert into jdbc (username,userno) values (\"Mac\","+i+")";
			//System.out.println(sql);
			String sql="select * from image where id=1";
			rs=stat.executeQuery(sql);
			rs.next();
			int i=rs.getInt("id");
			Blob conver=rs.getBlob("image");
			//Image im=ImageIO.read(conver.getBinaryStream());
			//System.out.println(conver.getBinaryStream());
	//	}
		stat.close();
		
	}

}
