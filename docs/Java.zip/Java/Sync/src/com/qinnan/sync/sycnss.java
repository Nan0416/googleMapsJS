package com.qinnan.sync;



public class sycnss {
	private int hu;
	private static int count=0;
	private boolean flag;
	public sycnss(){
		hu=0;
		//count++;
		flag=false;
	}
	public synchronized void print() throws InterruptedException{
		while(hu<20){
			hu--;
			wait();
			//this.wait();
		}
		flag=true;
		System.out.println("HU = "+hu);
	}
	public synchronized void increase(){
		hu+=10;
		count++;
		System.out.println("Count = "+count);
		notifyAll();
	}
	public boolean isPrinted(){
		return flag;
	}
}
