package com.qinnan.sync;

public class Wrap {
	private sycnss hu;
	public Wrap(){
		hu=new sycnss();
	}
	public Runnable print(){
		return new Runnable(){
			public void run(){
				try {
					hu.print();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
	}
	public Runnable increase(){
		return new Runnable(){
			public void run(){
				hu.increase();
			}
		};
	}
	public boolean isPrinted(){
		return hu.isPrinted();
	}
}
