package com.qinnan.tern;

public class qin {
	public static void main(String [] args){
		String hu ="huas"+ ( true?"nan":"ok" )+ "some";
		System.out.println(hu);
		int huu =(hu.length()>10)? hu(12):hu(23);
		 // once compute
	}
	public static int hu(int j){
		System.out.println(j);
		return 1;
	}

}
