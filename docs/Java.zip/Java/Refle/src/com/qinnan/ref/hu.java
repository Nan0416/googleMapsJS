package com.qinnan.ref;

public class hu {
	private int hu;
	private int hu(){
		return 2;
	}
	private String hu2(){
		return "Nan";
	}
	public int hu4;
	public int hu5;
	public String uuu;
	public String re(){
		return "";
	}
	public char [] ii(){
		return new char[12];
	}
	public class hu23{
		public int hu;
	}
	public hu(){
		hu4=10223;
		uuu="qinnan";
		
	}

}
