package com.qinnan.ref;

import java.lang.reflect.Field;
import java.util.Arrays;

public class dir {
	public static void main(String [] args) throws Exception{
		/*dir n=new dir();
		Class c2=Class.forName("java.lang.Class");
		//class itself class
		//forname static mehtod(String "ClassName") return a class 
		System.out.println(c2.getClass().getName());
		String i="qina".getClass().newInstance();
		System.out.println(i.length()); 
		
		*/
		Class ana=hu.class;
		//ana is a general type class of hu; it doesn't contain the content of hu.
		Field [] f=ana.getFields();
		/*
		 * Returns an array containing Field objects reflecting
		 *  all the accessible public fields of the class or interface
		 *   represented by this Class object.
		 *   
		 *   only public
		 *   
		 */
		
		System.out.println(Arrays.toString(f));
		
		for(Field i:f){
			System.out.println(i.getName());
			//String field name;
			
		}
		Field jj=ana.getDeclaredField("hu4");
		//jj is indicate the "hu4"
		hu u3=new hu();
		int a=(int) jj.get(u3);
		//robbery u3
		System.out.println(a);
		jj.set(u3,12);
		System.out.println(u3.hu4);
		
	}

}
