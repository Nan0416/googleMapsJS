package com.qinnan.run;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MyRun{
	private int hu=0;
	public Runnable getRun1(){
		return new Runnable(){
			@Override
			public void run(){
				for(int i=0;i<1000;i++){
					for(int j=0;j<10000;j++){
						for(int k=0;k<10000;k++){
							boolean flag=false;//,flag2=false;
							
							//try{
								flag=Thread.currentThread().isInterrupted();
								//flag2=Thread.interrupted();
							//}catch(InterruptedException e){
							//it doesn't throw exception
							//sleep throws exception
								/*
								 * once a thread was sleeping
								 * if it is interrupted will cause exception
								 */
							//}
							if(flag){
								Logger.getGlobal().info("interrupted");
								return;
							}
							if(j==0&&k==0){
								System.out.println("This is Run1 "+i);	
							}	
						}
					}
				}
			}
		};
	}
	public Runnable getRun2(){
		return new Runnable(){
			public void run(){
				for(int i=0;i<1000;i++){
					for(int j=0;j<10000;j++){
						for(int k=0;k<10000;k++){
							boolean flag2=Thread.currentThread().isInterrupted();
							if(flag2){
								Logger.getGlobal().info("interrupted");
								return;
							}
							
							if(j==0&&k==0){
								System.out.println("This is Run2 "+i);	
								try {
									Thread.sleep(2000);
									//although it is static, but only the thread which has sleep() will sleep
									//for example, only getRun2 sleep, getRun1 don't
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									Logger.getGlobal().log(Level.INFO, "sleep 3s", e);
								}
							}	
						}
					}
				}
				
			}
		};
	}
	public void printhu(){
		while(true){
			for(int i=0;i<10000;i++){
				for(int j=0;j<90000;j++){
					if(j==0&&i==0){
						System.out.println(hu);
					}
					if(j==2&&i==1){
						try {
							System.out.println("will sleep");
							Thread.sleep(4000);
							System.out.println("wake up");
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
		}
	}
	public Runnable getInput(){
		return new Runnable(){
			public void run(){
				Logger.getGlobal().info("enter hu:  ");
				Scanner in=new Scanner(System.in);
				hu=in.nextInt();
			}
		};
	}
	
	
	
	
	
}
