package com.qinnan.run;

import java.util.logging.Logger;

public class Drie {
	public static void main(String [] args){
		MyRun myrun=new MyRun();
		
		Runnable myrun1=myrun.getRun1();
		Thread t2=new Thread(myrun1);
		t2.setDaemon(true);
		t2.start();
		//t2.interrupt();
		
		
		/*//t2.start();
		myrun.printhu();
		//Thread.interr
		//@Deprecated
		Logger.getGlobal().info("will stop");
		Thread.currentThread().stop();*/
		// stop is never executed, cause the myrun.printhu() never stop;
		/*Runnable myrun1=myrun.getInput();
		Thread t=new Thread(myrun1);
		myrun.printhu();
		System.out.println("main thread sleeped");
		t.start();*/
		
		/*Runnable myrun1=myrun.getRun1();
		Runnable myrun2=myrun.getRun2();
		Thread t=new Thread(myrun1);
		Thread t2=new Thread(myrun2);
		Thread t3=new Thread(myrun1);
		t.start();
		t2.start();
		//t3.start();
		Logger.getGlobal().info("Dri");
		
		//t.interrupt();*/
	}
}