package com.qinnan.string;
import com.qinnan.parseString.Drive;
public class drive {
	public static void main(String [] args) throws ClassNotFoundException{
		Drive parser = new Drive();
		//parser.Parse(Class.forName("java.lang.StringBuilder"));
		StringBuilder sb = new StringBuilder();
		sb.append("qinnan");
		sb.append(21);
		sb.append(19.0);
		System.out.println("current capacity: "+sb.capacity());
		// insert offset is make the string 
		sb.insert(1," is ");
		
		String hu = sb.toString();
		System.out.println(hu);
		sb = sb.reverse();
		System.out.println(sb);
		sb.insert(1, "si");
		System.out.println(sb+"\n"+sb.indexOf("si")+"\n"+sb.lastIndexOf("si",10));
		sb.delete(sb.indexOf("si"), sb.indexOf("si")+"si".length());
		System.out.println(sb+"\n"+sb.indexOf("si")+"\n"+sb.lastIndexOf("si"));
		System.out.println("current capacity: "+sb.capacity());
		char hu2 = sb.charAt(6);
		
		System.out.println(hu2);
		byte hu3 = (byte)hu2;
		System.out.println(hu3);
		int hu4 = sb.codePointAt(6);
		System.out.println(hu4);
		//System.out.println(sb.substring(10,100));
		
	}

}
