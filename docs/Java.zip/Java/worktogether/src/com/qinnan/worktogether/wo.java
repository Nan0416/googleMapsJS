package com.qinnan.worktogether;

public class wo {
	private int result=0;
	private int result2=0;
	public Runnable cal(){
		return new Runnable(){
			public void run(){
				for(int i=0;i<1000;i++){
					for(int j=0;j<10000;j++){
						for(int k=0;k<10000;k++){
							result=10;
						}
					}
				}
			}
		};
	}
	public Runnable cal2(){
		return new Runnable(){
			public void run(){
				for(int i=0;i<1000;i++){
					for(int j=0;j<10000;j++){
						for(int k=0;k<10000;k++){
							result2=12;
						}
					}
				}
			}
		};
	}
	public Runnable pri(int i){
		return new Runnable(){
			public void run(){
				switch (i){
				case 1:System.out.println("cla competed result"+result);break;
				case 2:System.out.println("cla competed result2"+result2);break;
				}
				
			}
		};
	}
}
