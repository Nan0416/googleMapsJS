package com.qinnan.worktogether;

import java.io.IOException;
import java.lang.Thread.State;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

public class drive {
	public static void main(String [] args){
		wo w=new wo();
		Thread t1=new Thread(w.cal());
		Thread t2=new Thread(w.cal2());
		Thread t3=new Thread(w.pri(1));
		Thread t4=new Thread(w.pri(2));
		System.out.println("Cal start");
		int o=6;
		assert o<=10&&o>=1:"priority error";
		t1.setPriority(o);
		t1.start();
		t1.setPriority(o+1);
		t2.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
			
			@Override
			public void uncaughtException(Thread t, Throwable e) {
				// TODO Auto-generated method stub
				FileHandler filelog;
				Logger logger=Logger.getLogger("Name");
				logger.setUseParentHandlers(false);
				
				try{
					filelog=new FileHandler("%h/drive%gth.log");
					logger.addHandler(filelog);
				}catch(IOException ee){
					ee.printStackTrace();
					//ee is the exception to create filelog
				}
				logger.log(Level.INFO,"Name2",e);
				
						
				
			}
		});
		t2.start();
		try{
		t2.setPriority(-1);
		}catch(IllegalArgumentException e){
			t2.setPriority(Thread.NORM_PRIORITY);
		}
		boolean flag1=true;
		boolean flag2=true;
		while(true){
			if(t1.getState()==Thread.State.TERMINATED&&flag1==true){//flag guarantee only start once
				flag1=false;
				Logger.getGlobal().info("res1");
				t3.start();
			}
			if(t2.getState()==Thread.State.TERMINATED&&flag2==true){//flag guarantee only start once
				flag2=false;
				Logger.getGlobal().info("res2");
				t4.start();
			}
			if(t3.getState()==Thread.State.TERMINATED&&t4.getState()==Thread.State.TERMINATED){
				break;
			}
		}
	}
}
