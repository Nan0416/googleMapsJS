package com.qinnan.anoy2;

public interface anon {
	public void out();
	public void out2();
}
