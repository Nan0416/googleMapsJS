package com.qinnan.anoy2;

public class dir {
	public static void main(String [] args){
		anon a=new anon(){
			@Override
			public void out(){
				System.out.println("This is out");
			}
			@Override
			public void out2(){
				System.out.println("This is out2");
			}
			public void out3(){
				System.out.println("This is out3");
			}
		};
		a.out();
		a.out2();
		//a.out3();
		//cause a is anon type, although its content is the extended class
		//unfortunately, since the extended class does not have a name
		// so you cannot cast it;
		
	}
}
