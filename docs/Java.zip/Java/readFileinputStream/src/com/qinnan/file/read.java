package com.qinnan.file;

import java.io.FileInputStream;
import java.io.IOException;

public class read {
	public static void main(String [] args) throws IOException{
		FileInputStream file_in=new FileInputStream("/Users/hatakusunoki/Documents/Java/ArbitDrive.java");
		int b=0;
		int i=0;
		b=file_in.read();
		while(b!=-1){
			if(b<=0xf){
				System.out.print(0);
			}
			System.out.print(Integer.toHexString(b)+" ");
			if(++i==10){
				i=0;
				System.out.println();
			}
			
			b=file_in.read();
		}
		file_in.close();
		int u;
		System.out.println();
		
	
	
	}

}
