package com.qinnan.runn;

public class runmen implements Runnable{
	private int hu;
	private int hu2;
	private static int i=0;
	public runmen(){
		hu=0;
		i++;
		hu2=10000;
	}
	public void run(){
		int tem=(int)(Math.random()*1000000);
		hu+=tem;
		hu2-=tem;
		int temp=hu+hu2;
		System.out.println(Thread.currentThread().toString()+" i: "+i+" rand: "+tem+" total: "+temp);
	}

}
