package com.qinnan.runn;

public class dri {
	private final static int Total=1000;
	public static void main(String [] args){
		runmen r=new runmen();
		Thread [] t=new Thread [Total];
		for(int i=0;i<Total;i++){
			t[i]=new Thread(r);
		}
		for(int i=0;i<Total;i++){
			t[i].start();
		}
	}
}
