package hello.qinnan;
public class Package{
    public void out(){
        System.out.println("This is Package");
    }
}