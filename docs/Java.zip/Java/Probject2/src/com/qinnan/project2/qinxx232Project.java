package com.qinnan.project2;
// Name: Nan Qin
// student id: 5212291
// x500: qinxx232
// section: 5
import java.lang.IllegalStateException;
import java.lang.StringBuilder;

public class qinxx232Project {
	public static void main(String [] args)  
	  {  
	    Ordering<String> ordering = new Ordering<String>();  
	  
	    ordering.precedes("A", "B"); 
	    ordering.precedes("A", "C");  
	    ordering.precedes("B", "D");  
	    ordering.precedes("B", "J");  
	    ordering.precedes("C", "E");  
	    ordering.precedes("D", "F");  
	    ordering.precedes("D", "H");  
	    ordering.precedes("E", "H");  
	    ordering.precedes("F", "C");  
	    ordering.precedes("G", "E");  
	    ordering.precedes("G", "I");  
	    ordering.precedes("I", "D");  
	    ordering.precedes("I", "J");  
	   
	    System.out.println(ordering.satisfy());  
	    // my answer: A < B < G < I < D < J < F < C < E < H
	    
	    Ordering<Integer> numbers = new Ordering<Integer>();
	    numbers.precedes(1, 2);
	    numbers.precedes(2, 3);
	    numbers.precedes(3, 4);
	    numbers.precedes(4, 5);
	    numbers.precedes(5, 6);
	    numbers.precedes(6, 7);
	    numbers.precedes(7, 8);
	    numbers.precedes(8, 9);
	    
	    
	    System.out.println(numbers.satisfy());
	    // 1 < 2 < 3 < 4 < 5 < 6 < 7 < 8 < 9 
	    
	  }  

}

class Ordering<Base>{
	private class Pair{
		private Base left;
		private Base right;
		private Pair next;
		
		private Pair(){
			left = null;
			right = null;
			next = null;
		}
	}
	
	private class Element{
		private Base object;
		private Element next;
		
		private Element(){
			object = null;
			next = null;
			
		}
		
	}
	
	private Pair pairs;
	private Element elements;
	
	
	public Ordering(){
		elements = new Element();
		pairs = null;
		
	}
	
	private boolean isEmpty(){
		return elements.next == null;
	}
	
	private boolean isElement(Base object){
		Element here = elements.next;
		while(here != null){
			if(here.object.equals(object)){
				return true;
			}
			here = here.next;
		}
		return false;
	}
	
	private boolean isPair(Base left, Base right){
		Pair here = pairs;
		while(here != null){
			if(here.left.equals(left) && here.right.equals(right)){
				return true;
			}
			here = here.next;
		}
		return false;
	}
	
	private boolean isMinimum(Base right){
		Element here = elements.next;
		while(here != null){
			if(isPair(here.object, right)){
				return false;
			}
			here = here.next;
		}
		return true;
	}
	
	private Base minimum(){
		Element before = elements;
		Element after = elements.next;
		
		while(after != null){
			if(isMinimum(after.object)){
				before.next = after.next;
				return after.object;
			}else{
				before = after;
				after = after.next;
			}
		}
		throw new IllegalStateException();
	}
	
	public void precedes(Base left,Base right){
		if(left == null || right == null){
			throw new IllegalStateException();
		}
		Pair temp = new Pair();
		temp.left = left;
		temp.right = right;
		temp.next = null;
		
		Pair here = pairs;
		
		if(here == null){
			pairs = temp;
			
		}else{
			
			while(here.next != null){
				here = here.next;
			}
			here.next = temp;	
		}
		
		
		if(!isElement(left) || !isElement(right)){
			Element tempEle = elements;
			while(tempEle.next != null){
				tempEle = tempEle.next;
			}
			if(!isElement(left)){
				tempEle.next = new Element();
				tempEle.next.object = left;
				tempEle = tempEle.next;
			}
			if(!isElement(right)){
				tempEle.next = new Element();
				tempEle.next.object = right;
				tempEle = tempEle.next;
			}
		}
		
	}
	
	public String satisfy(){
		StringBuilder temp = new StringBuilder();
		while(!isEmpty()){
			temp.append(minimum().toString()+" < ");
		}
		if(temp.length() == 0){
			return "";
		}else{
			return temp.delete(temp.length()-3,temp.length()-1).toString();
		}
	}
	

}
