package messy;

public class messy {
	public static void main(String [] args){
		E x = new E();
		System.out.println(x.fun2()+" "+x.fun3());
		F y = x;
		System.out.println(y.fun2());//+" "+y.fun3());
		System.out.println(((E) y).fun3());
		
		//System.out.println(x.super.fun2());
		//only class can call .super
		G v = new G();
		System.out.println(v.fun(12));
		System.out.println(v.fun(1,2,3));
		System.out.println(v.fun(2,3));
	}
}

interface A{
	public int hu=0;
	//private int uu = 0;
	public static int uu = 0;
	public int fun();
}
interface B{
	public String fun();
}

interface C extends B{
	
}
// never work normally, class can not implements A and B simultaneously
//class Con implements A,B{
//
//	@Override
//	public String fun() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//}

class F{
	public int fun2(){
		return 11;
	}
}
class E extends F{
	public String fun3(){
		return "qin";
	}
}
class G{
	public int fun(int... args){
		return 2;
	}
	public int fun(int a, int b){
		return 3;
	}
	public int fun(int a){
		return 1;
	}
	
}

