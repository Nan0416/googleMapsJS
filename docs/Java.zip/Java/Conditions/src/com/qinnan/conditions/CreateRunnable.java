package com.qinnan.conditions;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

public class CreateRunnable {
	private int hu;
	private static int count=0;
	private Lock lock;//=new ReentrantLock();
	private Condition enoughHu;
	private Condition enoughHu2;
	private boolean flag;
	public CreateRunnable(){
		hu=1;
		lock=new ReentrantLock();
		enoughHu=lock.newCondition();
		enoughHu2=lock.newCondition();
		if(enoughHu==enoughHu2){
			Logger.getGlobal().info("==");
		}else{
			Logger.getGlobal().info("!=");
		}
		flag=false;
	}
	public boolean isPrinted(){
		return flag;
	}
	public Runnable print(){
		return new Runnable(){
			public void run(){
				lock.lock();
				try{
					//hu+=10;
					while(hu<20){
						try {
							System.out.println("before await()");
							enoughHu.await();
							System.out.println("after await()");
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					flag=true;
					System.out.println("Hu = "+hu);
					
				}finally{
					lock.unlock();
				}
			}
		};
	}
	public Runnable increase(){
		return new Runnable(){
			public void run(){
				lock.lock();
				try{
					hu+=10;
					System.out.println("count "+(++count));
					enoughHu.signalAll();
				}finally{
					lock.unlock();
				}
			}
		};
	}

}
