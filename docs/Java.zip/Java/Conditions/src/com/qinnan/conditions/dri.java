package com.qinnan.conditions;

import java.util.logging.Level;
import java.util.logging.Logger;

public class dri {
	public static void main(String [] args){
		CreateRunnable r=new CreateRunnable();
		Thread t1=new Thread(r.print());
		Thread t2=null;//=new Thread(r.increase());
		Logger.getGlobal().setLevel(Level.WARNING);
		t1.start();
		boolean flag=true;
		do{
			if(flag==true||t2.getState()==Thread.State.TERMINATED){
				t2=new Thread(r.increase());
				Logger.getGlobal().info("will"+t2.getState());
				t2.start();
				Logger.getGlobal().info("done");
				flag=false;
			}
		}while(t1.getState()!=Thread.State.TERMINATED&&!r.isPrinted());
	}
}
