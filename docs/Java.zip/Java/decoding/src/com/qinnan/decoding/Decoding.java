package com.qinnan.decoding;

import java.io.UnsupportedEncodingException;

public class Decoding {
	public static void main(String [] args) throws UnsupportedEncodingException{
		String hu="偡婾łŃń";
		byte[] hu2=hu.getBytes("utf-16be");
		byte[] hu3=new byte[hu2.length];
		for(int i=0;i<hu2.length;i++){
			hu3[i]=(byte)((int)hu2[i]-1);
		}
		String hu4=new String(hu3,"utf-16be");
		System.out.println(hu4);
	}
}
