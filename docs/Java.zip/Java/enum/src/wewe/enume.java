package wewe;

import java.util.Arrays;

public class enume {
	private enum sie{
		SSS,LLL;
	}
	public static void main(String [] args){
		Size s=Enum.valueOf(Size.class, "LARGE");
		Size s2=Size.LARGE;
		//return the value of SMALL
		if(s==Size.LARGE){
			System.out.println(Arrays.toString(Size.values())+"\n"+s.get()+"\n"+s.get2());
		}
		
	}
}
enum Size{
	SMALL("S",4),MEDIUM("M"),LARGE("L");
	private String abb;
	private Size(String add){
		abb=add;
	}
	private int u;
	private Size(String s,int a){
		u=a;
		abb=s;
	}
	public int get2(){
		return u;
	}
	public String get(){
		return abb;
	}
	
}
