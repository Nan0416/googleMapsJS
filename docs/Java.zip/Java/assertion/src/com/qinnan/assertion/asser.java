package com.qinnan.assertion;

public class asser {
	public static void main(String [] args){
		int x=-1;
		assert x>0;
		System.out.println(Math.sqrt(x));
		
	}

}
class sort{
	public static void method(int[] a,int start,int end) throws Throwable{
		assert a!=null;
		assert start>0;
		if(start<0){
			throw new Throwable(){
				public void print(){
					System.out.println(this.getClass().getName());
				}
			};
		}
		if(end>a.length){
			throw new Throwable(){
				public void print(){
					System.out.println(this.getClass().getName());
				}
			};
		}
		
	}
	
}