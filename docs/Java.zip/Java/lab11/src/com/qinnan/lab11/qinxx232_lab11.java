package com.qinnan.lab11;

public class qinxx232_lab11 {
	public static void main(String [] args)  
	  {  
	    FamilyTree family = new FamilyTree("Al");  
	    family.addParents("Al", "Harry", "Ginny");  
	    family.addParents("Harry", "James", "Lily");  
	    family.addParents("Ginny", "Arthur", "Molly");  
	    try{
	    	family.addParents("Mike","Charles","Lucy"); // trigger a exception
	    }catch(IllegalArgumentException e){
	    	System.out.println(e+" catched.");
	    }
	  
	    System.out.println(family.isDescendant("Al", "Molly"));       //  true  
	    System.out.println(family.isDescendant("Ginny", "James"));    //  false  
	    System.out.println(family.isDescendant("Harry", "Salazar"));  //  false  
	    
	  }  
	

}

class FamilyTree{
	private class Node{
		private String name;
		private Node father;
		private Node mother;
		private Node(String name, Node father, Node mother){
			this.name = name;
			this.father = father;
			this.mother = mother;
		}
	}
	private Node root;
	public FamilyTree(String ego){
		root = new Node(ego, null, null);
		
	}
	private Node find(String name){
		return find(name, root);
		
	}
	
	private Node find(String name, Node root){
		Node father = null;
		Node mother = null;
		Node self = null;
		if(root == null){
			return null;
		}else{
			if(root.father != null){
				father = find(name, root.father);
			}
			if(root.mother != null){
				mother = find(name, root.mother);
			}
			if(root.name.equals(name)){
				self = root;
			}
		}
		if (father != null){
			return father;
		}else if(mother != null){
			return mother;
		}else{
			return self;
		}		
	}
	public void addParents(String ego, String father, String mother){
		Node temp = find(ego);
		if(temp == null){
			throw new java.lang.IllegalArgumentException();
		}
		temp.father = new Node(father, null, null);
		temp.mother = new Node(mother, null, null);
	}
	public boolean isDescendant(String ego, String ancestor){
		Node temp_ego = find(ego);
		if(temp_ego == null){
			return false;
		}
		Node temp_anc = find(ancestor);
		if(temp_anc == null){
			return false;
		}
		return isDescendant(temp_ego, temp_anc);
	}
	private boolean isDescendant(Node root, Node ancestor){
		boolean temp_father = false;
		boolean temp_mother = false;
		boolean self = false;
		if(root == null){
			return false;
		}
		else{
			if(root.father != null){
				temp_father = isDescendant(root.father, ancestor);
			}
			if(root.mother != null){
				temp_mother = isDescendant(root.mother, ancestor);
			}
			if(root == ancestor){
				self = true;
			}
		}
		return self | temp_mother | temp_father;
		
	}
	
}
