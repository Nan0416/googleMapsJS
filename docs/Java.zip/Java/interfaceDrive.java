import com.qinnan.interfaceintro.*;
public class interfaceDrive{
    public static void main(String [] args){
        interimple i=new interimple();
        i.compare();
        System.out.println(i.getClass().getName());
        i.rrr(i);
    }
}