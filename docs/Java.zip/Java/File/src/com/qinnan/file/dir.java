package com.qinnan.file;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class dir {
	public static void main(String [] args) throws IOException{
		String hu="你好ABC";
		byte [] hu2=hu.getBytes();
		
		//change string to byte array
		for(byte i:hu2){
			System.out.print(Integer.toHexString(i&0xff)+" ");
			// one byte 8 bits, change to int 32 bit the first 3 bits are 0
			//so & 00 00 00 ff
		}
		System.out.println(); 
		byte [] hu3=hu.getBytes("gbk");//without arg to the system default utf-8
		//get from gbk
		//gbk chinese word two byte, english character one byte
		for(byte i:hu3){
			System.out.print(Integer.toHexString(i&0xff)+" ");
			// one byte 8 bits, change to int 32 bit the first 3 bits are 0
			//so & 00 00 00 ff
		}
		System.out.println(); 
		byte [] hu4=hu.getBytes("utf-16be");
		//java's form of coding, no matter english or other words 
		//change string to byte array
		for(byte i:hu4){
			System.out.print(Integer.toHexString(i&0xff)+" ");
			// one byte 8 bits, change to int 32 bit the first 3 bits are 0
			//so & 00 00 00 ff
		}
		/*
		 * when you want to write some words, you will use one type of coding, like utf-8
		 * the the editor will change it to the binary coding
		 * like A in utf-8 will as 41 but if you decoding with utf-16ge, it will take 16 bits as a word
		 * therefore will cause chaos
		 */
		String hu5=new String(hu4);//change a byte array to a string with the default translator
		System.out.println("\n"+hu5);
		String hu6=new String(hu4,"utf-16be");//change a byte array to a string with the indicated translator
		System.out.println(hu6);
		String hu7="联通";
		byte [] hu8=hu7.getBytes();
		//java's form of coding, no matter english or other words 
		//change string to byte array
		for(byte i:hu8){
			System.out.print(Integer.toHexString(i&0xff)+" ");
			// one byte 8 bits, change to int 32 bit the first 3 bits are 0
			//so & 00 00 00 ff
		}
		String hu9=new String(hu8,"utf-16be");
		System.out.println("\n"+hu9);
		String hu10="铩肚";
		byte [] hu11=hu10.getBytes("utf-16be");
		//java's form of coding, no matter english or other words 
		//change string to byte array
		for(byte i:hu11){
			System.out.print(Integer.toHexString(i&0xff)+" ");
			// one byte 8 bits, change to int 32 bit the first 3 bits are 0
			//so & 00 00 00 ff
		}
		
	}
}
