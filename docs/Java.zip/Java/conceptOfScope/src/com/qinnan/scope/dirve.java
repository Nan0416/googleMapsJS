package com.qinnan.scope;

public class dirve {
	public static void main(String [] args){
		System.out.println(hu(8));
		
	}
	public static double hu(int x){
		double r=10;
		while(true){
			if(x<10){
			// from clojure, you let [r …] the scope of r cannot arrive the return statement.
				r= Math.sqrt(r);
				x++;
			}else{
				return r;
			}
		}

		
	}

}
