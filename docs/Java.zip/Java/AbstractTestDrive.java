import com.qinnan.Abstract.*;
public class AbstractTestDrive{
    public static void main(String [] args){
        //AbstractTest a1=new AbstractTest(); abstract class cannot be instantiated;
        Student a2=new Student();
        a2.setName("qin1");
        System.out.println(a2.getName()+a2.outputDescription()+a2.outputDescription(" Of course."));
    
    }
}