package com.qinnan.callback;
//import java.awt.event.*;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.Timer;
public class CallEvent {
	public static void main(String [] args){
		Timer t=new Timer(1000,new hello());
		t.start();
		//JOptionPane.showMessageDialog(null,"Quit?");
		//Scanner in=new Scanner(System.in);
		//in.next();
		//System.exit(0);
	}
}
