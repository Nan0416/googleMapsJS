package com.qinnan.callback;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class hello implements ActionListener{
	private static int i=0;
	private String te;
	Scanner in=new Scanner(System.in);
	public void actionPerformed(ActionEvent event){
		System.out.print("Enter:  ");
		te=in.next();
	}
	
}