package com.qinnan.dot;

public class dri {
	public static void main(String [] args){
		Class s=String.class;
		System.out.println(s.getName());
	}
}
