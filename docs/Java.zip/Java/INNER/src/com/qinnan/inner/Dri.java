package com.qinnan.inner;

public class Dri {
	public static void main(String [] args){
//		TestInner hu=new TestInner();
//		hu.sethu(-10);
//		TestInner.inner ii=hu.newInner();
//			int i=ii.gethu();
//			System.out.println(i);
		PublicPrivate time = new PublicPrivate(211,8.01);
		time.showtime();
		PublicPrivate.Timezone tool = time.new Timezone(0,2);
		tool.setTimezone(-1);
		tool.adjust();
		time.showtime();
		//System.out.println(time.er);
		//PublicPrivate.Timezone2 tool2 =time.createinner();
		localinnerclass date = new localinnerclass();
		//date.showtime();
		date.adjust(10);
		//
		//.showtime();
	}
	
}
