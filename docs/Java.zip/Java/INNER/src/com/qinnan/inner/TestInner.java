package com.qinnan.inner;

public class TestInner {
	private int hu;
	public void sethu(int hu){
		this.hu=hu;
	}
	public inner newInner(){
		return new inner();
	}
	public class inner{
		private int hu;
		public inner(){
			this.hu=TestInner.this.hu;
		}
		public int gethu(){
			return this.hu;
		}
	}
	public void oi(boolean o){
		boolean iwe=true;
		if(hu>10){
			class localinner1{
				void set(){
					//o=false;  local variable should be final;
					//iwe=false;
				}
			}
			
		}else{
			o=true;
		}
		iwe=false;
	}
}
