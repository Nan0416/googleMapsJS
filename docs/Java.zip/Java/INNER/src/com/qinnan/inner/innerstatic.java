package com.qinnan.inner;

public class innerstatic {
	private int counter = 0;
	private static class Data{
		public static int j = 10;
		public int i=-10;
		public void add(){
			//counter ++;
			//
			i++;
		}
	}
	public void show(){
		//System.out.println(Data.i);
		System.out.println(Data.j);
	}
	//static cannot use non-static
	//here Data is static, i is non-static.
	
	
}
