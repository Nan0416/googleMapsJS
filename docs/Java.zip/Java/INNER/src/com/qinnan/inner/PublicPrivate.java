package com.qinnan.inner;



public class PublicPrivate {
	//protected int er=0;
	private int date = 0;
	private double time = 0.0;
	public PublicPrivate(int date, double time){
		this.date = date;
		this.time = time;
	}
	public void incDate(){
		date++;
	}
	public void showtime(){
		System.out.println(date + " " + time);
	}
	public Timezone2 createinner(){
		return new Timezone2(0);
	}
	public class Timezone{
		//private int date=0;
		private int timezone = 0;
		public Timezone(int timezone, int date){
			this.timezone = timezone;
			//this.date = date;
		}
		public void setTimezone(int timezone){
			this.timezone = timezone;
		}
		public void adjust(){
			switch(timezone){
				case 0:
					break;
				case 1:
					time = time + 1;break;
				case 2:
					time = time + 2;break;
				case -1:
					date --;
				case -2:
					date -= 2;
				default:
					break;
			}
		}
		
	}
	private class Timezone2{
		private int timezone = 0;
		public Timezone2(int timezone){
			this.timezone = timezone;
		}
		public void setTimezone(int timezone){
			this.timezone = timezone;
		}
		public void adjust(){
			switch(timezone){
				case 0:
					break;
				case 1:
					time = time + 1;break;
				case 2:
					time = time + 2;break;
				case -1:
					date --;
				case -2:
					date -= 2;
				default:
					break;
			}
		}
		
	}

}
