package com.qinnan.inner;

public class localinnerclass {
	private int time=20;
	
	public void adjust(int newtime){
		int timezone = 1000;	
		class innerlocal{
			private int config = 100;
			public innerlocal(){
				config = timezone;
			}
			public void addconfig(int cst){
				time = cst;
				
			}
			public void show(){
				System.out.println(time);
			}
		}
		class innerlocal2{
			private int temp =333;
			public void magic(int any){
				innerlocal some = new innerlocal();
				some.addconfig(temp);
				some.show();
				temp = any;
				some.show();
			}
		}
		//float in = 10f;
		innerlocal2 ai = new innerlocal2();
		ai.magic(10);
	}
	public void showtime(){
		System.out.println(time);
	}

}
