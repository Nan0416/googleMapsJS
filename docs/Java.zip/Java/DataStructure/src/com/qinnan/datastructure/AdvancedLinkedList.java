package com.qinnan.datastructure;

import java.util.AbstractCollection;
import java.util.Iterator;
import java.util.logging.Logger;

public class AdvancedLinkedList<E> extends AbstractCollection<E>{

	private E data;
	private AdvancedLinkedList<E> last;
	private AdvancedLinkedList<E> next;
	private AdvancedLinkedList<E> self;
	private int index;
	public AdvancedLinkedList(E data){
		this.data=data;
		index=0;
		last=next=null;
		self=this;
	}
	public AdvancedLinkedList(){
		data=null;
		index=0;
		last=next=null;
		self=this;
	}
	public boolean add(E nextData){
		if(this.data==null){
			try{
				self.data=nextData;
				index=0;
			}catch(Exception e){
				self.data=null;
				return false;
			}
			return true;
		}else{
			AdvancedLinkedList<E> next=new AdvancedLinkedList<E>(nextData);
			try{
				self.next=next;
				next.last=self;
				self=next;
				self.index=self.last.index+1;
			}catch(Exception e){
				self.next=null;
				return false;
			}
			return true;
		}
	}
	public boolean add(E nextData,int index){
		if(index<0||index>self.index+1){
			return false;
		}else if(index==self.index+1){
			return add(nextData);
		}else{
			AdvancedLinkedList<E> next=new AdvancedLinkedList<E>(nextData);
			next.index=index;
			AdvancedLinkedList<E> temp=self;
			while(index!=temp.index){
				temp=temp.last;
			}
			//Logger.getGlobal().info(temp.data.toString()+" "+temp.index+"\n"+self.data.toString()+" "+self.index);
			if(temp.last==null){
				temp.last=next;
				next.next=temp;
				return updateIndex();
			}else{
				next.last=temp.last;
				next.last.next=next;
				temp.last=next;
				next.next=temp;
				return updateIndex();
				
			}
		}
	
	}
	public boolean remove(){
		try{
			if(self.data!=null){
				if(self.last!=null){
					// this node is not the first node
					self=self.last;
					self.next.last=null;
					self.next=null;
					//self.index--;//self.index;
					
				}else{
					//this node is the first node
					last=next=null;
					index=0;
					data=null;
				}
					
			}else{
				return false;
			}
			
		}catch(Exception e){
			return false;
		}
		return true;
	}
	public boolean remove(int index){
		if(index<0||index>self.index){
			return false;
		}else if(index==self.index){
			return remove()&updateIndex();
		}else{
			AdvancedLinkedList temp=self;
			while(temp.index!=index){
				temp=temp.last;
			}
			if(temp.last==null){
				//first
				temp.next.last=null;
				temp.next=null;
			}else{
				temp.last.next=temp.next;
				temp.next.last=temp.last;
				temp.next=temp.last=null;
			}
			return true&updateIndex();
		}
		
	}
	private AdvancedLinkedList<E> checkIndex(){
		AdvancedLinkedList<E> temp=self;
		
		while(temp.last!=null){
			if((temp.index-temp.last.index)!=1){
				return temp;
			}
			temp=temp.last;
		}
		if(temp.last==null&&temp.index!=0){
			return temp;
		}
		return null;
	}
	private boolean updateIndex(){
		try{
			AdvancedLinkedList<E> temp=checkIndex();
			//System.out.println("====="+temp.index+" "+temp.data.toString());
			int tempIndex=0;
			if(temp==null){
				return true;
				//the link is normal
			}else{
				if(temp.last!=null){
					
					tempIndex=temp.last.index+1;
					//System.out.println("===="+tempIndex);
				}
				while(temp!=null){
					temp.index=tempIndex++;
					temp=temp.next;
					//System.out.println(temp.data.toString()+"  "+temp.index);
				}
				return true;
			}
		}catch(Exception e){
			return false;
		}
	}
	public void print(){
		AdvancedLinkedList<E> temp=self;
		while(temp!=null){
			System.out.println(temp.index+" "+temp.data.toString());
			temp=temp.last;
		}
	}
	public void printSelf(){
		System.out.println(self.index+" "+self.data.toString());
	}
	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
