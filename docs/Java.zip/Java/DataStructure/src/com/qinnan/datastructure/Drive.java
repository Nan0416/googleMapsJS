package com.qinnan.datastructure;

public class Drive {
	public static void main(String [] args){
		AdvancedLinkedList<String> stringList=new AdvancedLinkedList<>();
		for(int i=0;i<9;i++){
			stringList.add("qinnan"+i);
		}
		
		stringList.print();
		stringList.remove(2);
		//stringList.printSelf();
		//stringList.print();
		stringList.add("Hello",2);
		stringList.print();
		System.out.println("over");
		
	}

}
