package reader;

import java.io.*;
import java.util.Arrays;
public class drie {
	public static void main(String [] args) throws IOException{
		InputStreamReader in=new InputStreamReader(new FileInputStream(new File("/Users/hatakusunoki/Desktop/1.txt")),"utf-8");
		int i;
		while((i=in.read())!=-1){
			//read translate utf-8 and other charset into utf-16be
			System.out.println(i);
			char t=(char)i;
			System.out.println(t);
		}
		in.close();
		FileInputStream in2=new FileInputStream("/Users/hatakusunoki/Desktop/1.txt");
		byte [] ii=new byte[6];
		in2.read(ii);
		String hu=new String(ii,"utf-16be");
		System.out.println(Arrays.toString(ii)+" "+hu);
		String hwu="秦楠";
		System.out.println(hwu.length());
		char [] io=hwu.toCharArray();
		for(int iww=0;iww<io.length;i++){
			
		}
	}
}
