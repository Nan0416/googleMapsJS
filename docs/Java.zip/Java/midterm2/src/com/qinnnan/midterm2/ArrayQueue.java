package com.qinnnan.midterm2;

public class ArrayQueue <Base> {
	private int front;
	private int rear;
	private Base [] objects;
	
	public ArrayQueue(int size){
		front = 0;
		rear = 0;
		objects = (Base []) new Object [size];
	}
	
	public boolean isEmpty(){
		return rear == front;
	}
	
	public void enqueue(Base object){
		int nextRear = (rear + 1) % objects.length;
		if(front == nextRear){ // leave one element unused.
			throw new IllegalStateException("Queue is full.");
		}else{
			rear = nextRear;
			objects[rear] = object;
		}
	}
	
	public boolean isFull(){
		return front == (rear + 1) % objects.length;
	}
	
	public Base dequeue(){
		if(isEmpty()){
			throw new IllegalStateException("NTQ");
		}else{
			front = (front + 1) % objects.length;
			Base temp = objects [front];
			objects[front] = null; // not necessary, front always point to meaningless element.
			return temp;
		}
	}

}
