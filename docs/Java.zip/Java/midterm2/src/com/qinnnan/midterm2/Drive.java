package com.qinnnan.midterm2;

public class Drive {
	public static void main(String [] args){
		int [] a = new int[10];
		for(int i = 0; i < a.length; i++){
			a[i] = i;
		}
		int [] b = a.clone();
		a[3] = 33;
		for(int i = 0; i < a.length; i++){
			System.out.println(a[i] + " " + b[i]);
		}
		//System.out.println(a + " " + b);
		
		String [] str = new String [10];
		for(int i = 0; i < str.length; i++){
			str[i] = "qinnan";
		}
//		for(String e:str){
//			e = new String("qoo");
//		}
		//iterator cannot used to assign value
		for(String e:str){
			System.out.println(e);
		}
		String s2;
		String s3;
		s3 = s2 = new String("q");
		System.out.println(s3+s2);
		s3 = s2.equals("first")? "Nan":"Qin";
		System.out.println(s3);
		s3 = s2==null? null:s3;
		System.out.println(s3);
	}

}
