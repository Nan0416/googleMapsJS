import com.qinnan.returnName.*;
public class getNameDrive{
    public static void main(String [] args){
        getName_2 hu=new getName_2();
        getName_ huu=new getName_2();
        String er="";//must be initialized
        try{
            Class we=hu.getClass();
            er=we.getName();
        }catch(Exception e){
            e.printStackTrace();
        }
        System.out.println(er);
        System.out.println(huu.getClass().getName());
    }
}