package com.qinnan.hashtableChaining;

public class Testing {
	public static void main(String [] args){
		HashTable<String, String> table = new HashTable(769);
		table.put("Harry",     "Ginny");
	    table.put("Ron",       "Lavender");
	    table.put("Lucius",    "Narcissa");
	    table.put("Albus",     "Gellert");
	    table.put("Voldemort", "Voldemort");

	    System.out.println(table.get("Harry"));      //  Ginny
	    System.out.println(table.get("Ron"));        //  Lavender
	    System.out.println(table.get("Lucius"));     //  Narcissa
	    System.out.println(table.get("Albus"));      //  Gellert
	    System.out.println(table.get("Voldemort"));  //  Voldemort

	    table.put("Ron", "Hermione");
	    System.out.println(table.get("Ron"));        //  Hermione

	    System.out.println(table.has("Voldemort"));  //  true
	    table.remove("Voldemort");
	    System.out.println(table.has("Voldemort"));  //  false
	}

}
