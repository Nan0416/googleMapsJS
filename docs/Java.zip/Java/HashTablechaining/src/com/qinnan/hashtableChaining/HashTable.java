package com.qinnan.hashtableChaining;

public class HashTable<Key, Value> {
	private class Node{
		private Key key;
		private Value value;
		private Node next;
		private Node(Key key, Value value, Node next){
			this.key = key;
			this.value = value;
			this.next = next;
		}
	}
	private Object [] table;
	public HashTable(int length){
		table = new Object [length];
	}
	private int hash(Key key){
		return Math.abs(key.hashCode()) % table.length;
	}
	public void put(Key key, Value value){
		if(key == null){
			throw new IllegalArgumentException();
		}
		int index = hash(key);
		Node temp = (Node) table[index];
		while(temp != null){
			if(temp.key.equals(key)){
				temp.value = value;
				return;
				// avoid repeated
			}
			temp = temp.next;
		}
		table[index] = new Node(key, value, (Node)table[index]);
	}
	public Value get(Key key){
		int index = hash(key);
		Node temp = (Node)table[index];
		while(temp != null){
			if(temp.key.equals(key)){
				return temp.value;
			}
			temp = temp.next;
		}
		throw new IllegalArgumentException("404");
	}
	public boolean has(Key key){
		int index = hash(key);
		Node temp = (Node)table[index];
		while(temp != null){
			if(temp.key.equals(key)){
				return true;
			}
			temp = temp.next;
		}
		return false;
	}
	
	public void remove(Key key){
		// with head node, left and right trick
		int index = hash(key);
		table[index] = new Node(null, null, (Node)table[index]);
		Node left = (Node)table[index];
		Node right = left.next;
		while(right != null){
			if(right.key.equals(key)){
				left.next = right.next;
				break;
			}else{
				left = right;
				right = right.next;
			}
		}
		table[index] = ((Node)table[index]).next;
	}
	
}
