package com.qinnan.hashtableChaining;

class JamesHashTable<Key, Value>
{

//  NODE. A node in the association list of a bucket in TABLE.

  private class Node
  {
    private Key   key;    //  The key for this NODE.
    private Value value;  //  The value associated with KEY.
    private Node  next;   //  The next NODE in the list, or NULL.

//  Constructor. Make a new NODE with KEY, VALUE, and NEXT.

    private Node(Key key, Value value, Node next)
    {
      this.key   = key;
      this.value = value;
      this.next  = next;
    }
  }

  private Node      head;      //  Temporary head node for REMOVE. 
  private Object [] table;     //  The buckets of the hash table.

//  Constructor. Make a new HASHTABLE of LENGTH buckets. LENGTH should be a big
//  prime number, not close to a power of 2, for best results.

  public JamesHashTable(int length)
  {
    if (length > 0)
    {
      head  = new Node(null, null, null);
      table = new Object [length];
    }
    else
    {
      throw new IllegalArgumentException("Length is negative.");
    }
  }

//  HAS. Test if KEY is associated with a value.

  public boolean has(Key key)
  {
    Node temp = (Node) table[hash(key)];
    while (temp != null)
    {
      if (temp.key.equals(key))
      {
        return true;
      }
      else
      {
        temp = temp.next;
      }
    }
    return false;
  }

//  HASH. Return an index of the bucket in TABLE where KEY might be.

  private int hash(Key key)
  {
    return Math.abs(key.hashCode()) % table.length;
  }

//  GET. Return the VALUE associated with KEY. Throw an exception if KEY is not
//  in the HASHTABLE.

  public Value get(Key key)
  {
    Node temp = (Node) table[hash(key)];
    while (temp != null)
    {
      if (temp.key.equals(key))
      {
        return temp.value;
      }
      else
      {
        temp = temp.next;
      }
    }
    throw new IllegalArgumentException("No such key.");
  }

//  PUT. Associate VALUE with KEY. Throw an exception if KEY is NULL.

  public void put(Key key, Value value)
  {
    if (key == null)
    {
      throw new IllegalArgumentException("Key cannot be NULL.");
    }
    else
    {
      int index = hash(key);
      Node temp = (Node) table[index];
      while (temp != null)
      {
        if (temp.key.equals(key))
        {
          temp.value = value;
          return;
        }
        else
        {
          temp = temp.next;
        }
      }
      table[index] = new Node(key, value, (Node) table[index]);
    }
  }

//  REMOVE. Break the association between KEY and VALUE. Do nothing when KEY is
//  not in the HASHTABLE.

  public void remove(Key key)
  {
    int index = hash(key);
    head.next = (Node) table[index];
    Node left = head;
    Node right = head.next;
    while (right != null)
    {
      if (right.key.equals(key))
      {
        left.next = right.next;
        break;
      }
      else
      {
        left = right;
        right = right.next;
      }
    }
    table[index] = head.next;
    head.next = null;
  }
}

//  HASH EXAMPLE. Let's see if it works.
