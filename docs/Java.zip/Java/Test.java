//package hello.qinnan;
import hello.qinnan.Package;
public class Test{
    public static void main(String [] args){
        Package p=new Package();
        p.out();
    
    }
}