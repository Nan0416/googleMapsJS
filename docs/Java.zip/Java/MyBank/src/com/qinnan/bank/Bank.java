package com.qinnan.bank;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

public class Bank {
	int usersnumber;
	double [] accounts;
	double total;
	private Lock banklock=new ReentrantLock();//ReentrantLock implements Lock
	private Lock banklock2=new ReentrantLock();
	public Bank(int usersnumber,double [] accounts){
		this.usersnumber=usersnumber;
		this.accounts=accounts;
	}
	
	public Bank(int usersnumber,double inti){
		this.usersnumber=usersnumber;
		accounts=new double[usersnumber];
		for(int i=0;i<usersnumber;i++){
			accounts[i]=inti;
		}
	}
	public void transfer(int from, int to, double ammount){
		assert from>0&&from<=usersnumber;
		assert to>0&&to<=usersnumber;
		if(ammount<0||ammount>accounts[from]){
			return;
		}else{
			banklock.lock();
			try{
				System.out.println("First1 "+((ReentrantLock) banklock).getHoldCount());
				accounts[from]-=ammount;
				//System.out.println("reduced");
				accounts[to]+=ammount;
				
				//System.out.println("Added");
				//System.out.printf("transfer %10.2f from %d to %d, total %10.2f\n",ammount,from,to,);
				totalmoney();
				System.out.println("First2 "+((ReentrantLock) banklock).getHoldCount());
			}finally{
				banklock.unlock();
				//must in a finally block, since try block may throw exceptions to stop the method
				// and without unlock() other thread also cannot access the resource;
			}
		}
	}
	public double totalmoney(){
		total=0;
		banklock.lock();
		try{
			System.out.println("Second "+((ReentrantLock) banklock).getHoldCount());
			for(int i=0;i<usersnumber;i++){
				total+=accounts[i];
			}
		}finally{
			banklock.unlock();
		}
		
		return total;
	}
	public int getUsersNumber(){
		return usersnumber;
	}
	public double getMoney(int no){
		double t=0;
		banklock.lock();
		try{
			System.out.println("Third "+((ReentrantLock) banklock).getHoldCount());
			try{
				t=accounts[no];
			}catch(Exception e){
				Logger.getGlobal().info(no+"");
			}
		}finally{
			banklock.unlock();
		}
		return t;
	}
}
