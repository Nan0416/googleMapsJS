package com.qinnan.abstract_;

public class drive {
	public static void main(String [] args){
		//superabstract su = new superabstract();
		//abstract classs cannot be instantiated
		
	}

}
