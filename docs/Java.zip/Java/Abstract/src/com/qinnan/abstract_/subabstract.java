package com.qinnan.abstract_;

public abstract class subabstract extends superabstract{
	protected abstract String any();
}
