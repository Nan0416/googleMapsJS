package com.qinnan.abstract_;

public abstract class superabstract {
	private String name;
	public abstract String description();
	//private abstract String change();
	protected abstract String change();
	//public abstract superabstract();
	//constructor cannot be used with abstracted
	
	
}
	