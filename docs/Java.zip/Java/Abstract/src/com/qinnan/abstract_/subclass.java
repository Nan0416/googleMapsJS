package com.qinnan.abstract_;

public class subclass extends superabstract{

	@Override
	public String description() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected String change() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
