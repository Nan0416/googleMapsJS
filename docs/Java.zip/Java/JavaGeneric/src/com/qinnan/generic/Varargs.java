package com.qinnan.generic;

public class Varargs<U> {
	//@SafeVarargs
	public <T extends generic<String>> void method(T... args){
		for(T i: args){
			System.out.println(i);
		}
		
	}
	public <T> void method2(int n){
		//T temp = new T();
		T temp = (T) new Object();
		// meaningless.
	}
	public <T> T method3(Class<T> c1, int n){
		try {
			T temp = c1.newInstance();
			return temp;
		} catch (InstantiationException | IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public boolean equals(Object obj){
		return false;
		
	}

}
