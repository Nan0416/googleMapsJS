package com.qinnan.generic;

import java.util.ArrayList;

public class drive {
	public static void main(String [] args){
		generic<String> str = new generic<>();
		str.add("qinnan");
		str.add(" ");
		str.add("is");
		str.add(" ");
		str.add("a");
		str.add(" ");
		str.add("good");
		str.add(" ");
		str.add("man");
		str.add(".");
		System.out.println(str);
		System.out.println(str.findFirstIndex("a"));
		str.insert(3, " ");
		str.insert(4, "absolutely");
		//insert in index
		System.out.println(str);
		str.insert(0, ":");
		System.out.println(str);
		str.insert(13,"Yes");
		System.out.println(str);
		System.out.println(str instanceof generic);
		System.out.println(str instanceof generic<?>);
		
		generic<String> str2 =new generic<>("Brad");
		Varargs me = new Varargs();
		//me.method(str,str2,"SQ");
		me.method(str,str2);
		
		bigrealize b1 = new bigrealize(2);
		bigrealize b2 = new bigrealize(3);
		restrictgeneric judge = new restrictgeneric();
		System.out.println(judge.min(b1, b2));
		
		String[] array = new String [10];
		add(array);
		System.out.println(array[0]);
		
		ArrayList<String> temp = new ArrayList<>();
		temp.add("Qinnan");
		ArrayList temp2 = temp;
		temp2.add(str);
		temp = (ArrayList<String>) temp2;
		//System.out.println(temp.get(1));
	}
	public static void add(String [] args){
		args[0] ="qinnan";
	}

}
