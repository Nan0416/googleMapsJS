package com.qinnan.generic;
import java.lang.IllegalArgumentException;
public class generic<T> {
	private coll<T> pointer;
	private coll<T> header;
	private int counter;
	public generic(){
		header = null;
		pointer = null;
		counter = 0;
	}
	public generic(T ele){
		header = pointer = new coll<T>(ele);
		counter = 1;
	}
	
	public void add(T ele){
		if(pointer == null){
			header = pointer = new coll<T>(ele);
		}else{
			pointer.setNext(new coll<T>(ele));
			pointer = pointer.getNext();
		}
		counter++;
	}
	
	public int findFirstIndex(T ele){
		coll<T> temp = header;
		if (counter == 0){
			return -1;
		}
		for(int i = 0; i < counter; i++){
			if(temp.getCur().equals(ele)){
				return i;
			}else{
				temp = temp.getNext();
			}
		}
		return -1;
	}
	public void insert(int index, T ele){
		// insert in index
		coll<T> temp = header;
		coll<T> temp2;
		if(index > counter){
			throw new IllegalArgumentException();
		}else if(index == 0){
			
			header.setLast(new coll<>(ele));
			header = header.getLast();
			counter++;
			
		}else{
			for(int i = 1; i< index; i++){
				temp = temp.getNext();
				
			}
			temp2 = temp.getNext();
			if(temp2 == null){
				add(ele);
			}else{
				coll<T> temp3 = new coll<>(ele);
				temp3.setNext(temp2);
				temp.setNext(temp3);
				counter++;
			}
			
			
		}
	}
	public T get(int index){
		coll<T> temp = header;
		if(index >= counter){
			throw new IllegalArgumentException();
		}else{
			
			for(int i = 0; i < index ;i++){
				temp = temp.getNext();
			}
			
		}
		return temp.getCur();
	}
	public String toString(){
		String temp = "";
		coll<T> temp2 = header;
		for(int i = 0; i< counter; i++){
			temp = temp + temp2.getCur().toString();
			temp2 = temp2.getNext();
		}
		return temp;
	}
	class coll<T>{
		private coll<T> last;
		private T cur;
		private coll<T> next;
		public coll(T ele) {
			cur = ele;
			last = null;
			next = null;
			
		}
		
		public coll<T> getLast() {
			return last;
		}
		public void setLast(coll<T> last) {
			this.last = last;
			last.next = this;
		}
		public T getCur() {
			return cur;
		}
		public void setCur(T cur) {
			this.cur = cur;
		}
		public coll<T> getNext() {
			return next;
		}
		public void setNext(coll<T> next) {
			this.next = next;
			next.last = this;
			
		}
		
	}

}
