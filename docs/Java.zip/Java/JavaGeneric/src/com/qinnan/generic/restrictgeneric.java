package com.qinnan.generic;

public class restrictgeneric {
	public <T extends BIG> T min(T ele1, T ele2){
		// since this generic type must have the big, so you can use extends to restrict it.
		if (ele1.big(ele2)){
			return ele1;
		}else{
			return ele2;
		}
	}

}

interface BIG<T>{
	public boolean big(T ele);
}

class bigrealize implements BIG<bigrealize>{
	private int num;
	public bigrealize(int num){
		this.num = num;
	}
	@Override
	public boolean big(bigrealize ele) {
		return (num > ele.num);
	}
	public String toString(){
		return ""+num;
	}
}

class sequence<T>{
	private T[] temp = (T[])new Object[100];
	///private T[] temp = new T[100];
	
}

class superbound<T>{
	public void write(generic<? super T> temp){
		
	}
	
}