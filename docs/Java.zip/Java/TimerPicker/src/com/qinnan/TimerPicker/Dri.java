package com.qinnan.TimerPicker;

import java.awt.event.ActionListener;

public class Dri {
	public static void main(String [] args){
		TimerP time1=new TimerP(1000);//,false);
		time1.start(false);
		TimerP time2=new TimerP(1300);//,true);
		time2.start(true);
		//ActionListener n=time1.new TimePrinter();
		//only inner class can be private
		//once inner class is private
		//you cannot use above syntax to construct a inner class object
		//therefore, outer class should has a method 
		//public Inner newInner(){
		//		return new Inner();
		//}
	}
}
