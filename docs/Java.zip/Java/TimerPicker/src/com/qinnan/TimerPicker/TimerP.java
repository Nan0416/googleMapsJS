package com.qinnan.TimerPicker;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

public class TimerP {
	private int interval;
	//private boolean beep;
	private int timeclip=0;
	public TimerP(int interval){//,boolean beep){
		this.interval=interval;
		//this.beep=beep;
	}
	public void start(boolean beep){
		//local class  without any modifier
		class TimePrinter implements ActionListener{
			private boolean oi=true;
			private boolean oi2=true;
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(oi){
					oi2=beep;
					oi=false;
				}
				// TODO Auto-generated method stub
				timeclip=timeclip+interval;
				
				System.out.println(timeclip);
				if(oi2){
					Toolkit.getDefaultToolkit().beep();
					oi2=false;
				}else{
					oi2=true;
				}
			}
		}
		Timer t=new Timer(interval, new TimePrinter());
		t.start();
	}
	public void start2(boolean beep){
		
		Timer t=new Timer(interval, new ActionListener(){ 
			//without name,
			//directly new ActionListener()
			private boolean oi=true;
			private boolean oi2=true;		
			@Override
			public void actionPerformed(ActionEvent e) {					if(oi){
					oi2=beep;
					oi=false;
				}
				// TODO Auto-generated method stub
				timeclip=timeclip+interval;		
				System.out.println(timeclip);
				if(oi2){
					Toolkit.getDefaultToolkit().beep();
					oi2=false;
				}else{
					oi2=true;
				}
			}
		});
		t.start();
	}
	/*public class TimePrinter implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			timeclip=timeclip+interval;
			System.out.println(timeclip);
			if(beep){
				Toolkit.getDefaultToolkit().beep();
			}
		}
	}*/
	
}
