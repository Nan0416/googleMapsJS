package com.qinnan.interfaceRedcue;

public interface fun {
	public int fun2(int x,int y);
	public boolean funmap(int x);
}
