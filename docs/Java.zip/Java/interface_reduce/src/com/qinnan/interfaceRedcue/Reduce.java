package com.qinnan.interfaceRedcue;

public class Reduce {
	public int reduce(fun obj, int... args){
		int temp = args[0];
		for (int i = 1; i<args.length; i++){
			temp = obj.fun2(temp, args[i]);
		}
		return temp;
	}
	public int [] map(fun obj, int... args){
		int [] rs = new int[args.length];
		int j = 0;
		for (int i = 0; i< args.length; i++){
			if(obj.funmap(args[i])){
				rs[j] = args[i];
				j++;
			}else{
				//rs[j]=-1;
				//j++;
			}
			
			
		}
		return rs;
		
		
	}
}
