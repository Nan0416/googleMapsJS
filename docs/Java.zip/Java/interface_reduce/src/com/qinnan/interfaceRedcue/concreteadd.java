package com.qinnan.interfaceRedcue;

public class concreteadd implements fun{
	public int fun2(int x, int y) {
		return x+y;
	}

	@Override
	public boolean funmap(int x) {
		if(x>10){
			return true;
		}
		return false;
	}
}
