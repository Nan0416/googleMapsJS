package com.qinnan.interfaceRedcue;

public class drive {
	public static void main(String [] args){
		concreteadd obj = new concreteadd();
		Reduce hof = new Reduce();
		int hu = hof.reduce(obj, 1,2,3,4,5);
		System.out.println(hu);
		int [] rs = hof.map(obj, 1,11,32,-1,21,10,12);
		for (int i:rs){
			System.out.print(i+ " ");
		}
		// 
		fun hof2 = new fun(){

			@Override
			public int fun2(int x, int y) {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public boolean funmap(int x) {
				// TODO Auto-generated method stub
				return false;
			}
			
		};
		
	}
}
