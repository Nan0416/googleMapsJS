package com.qinnan.interfacemulti;

public class concrete implements interface1,interface2{

	@Override
	public void qinnan() {
		// TODO Auto-generated method stub
		
	}

}
