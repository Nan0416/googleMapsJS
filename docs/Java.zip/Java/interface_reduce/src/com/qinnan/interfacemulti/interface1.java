package com.qinnan.interfacemulti;

public interface interface1 {
	public abstract void qinnan();
}
