package com.qinnan.interfacemulti;

public interface interface2 {
	public void qinnan();

}
