import com.qinnan.arbitrary.*;
import static com.qinnan.arbitrary.Arbit.*;
import static java.lang.System.*;
import java.lang.Class;
public class ArbitDrive{
    public static void main(String [] args){
        Arbit j=new Arbit();
        j.out2(new Para1(),new Para2(),new Para2());
        j.out2(new Para2());
        j.out2(new ArbitDrive());
        j.out3((new Para1()),"\n",(new Para2()),"\n");
        String o="";
        System.out.println(o.getClass().getName());
        Class c1=int.class;
        Class c2=Para2.class;
        if(c2.equals(Para2.class)){
            System.out.println("Yes");
        }
        //Object t=c2.newInstance();
        //Para2 e=c2.newInstance();
        String s="";
        try{
            String w=s.getClass().getName();
            Class c4=Class.forName(w);
            Object qw=c4.newInstance();
            //String ee=c4.newInstance();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
