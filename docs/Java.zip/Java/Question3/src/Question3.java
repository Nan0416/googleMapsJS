
public class Question3 {
	public static void main(String [] args){
		Duplicate d = new Duplicate();
		int [] a = {1,2,4,5,6,2};
		System.out.println(d.hasDuplicate(a));
		
		
	}

}
class Duplicate{
	public boolean hasDuplicate(int [] args){
		int temp = 0;
		for (int i: args){
			temp = 0;
			for (int j: args){
				if(j == i){
					temp++;
				}
				
			}
		}
		if(temp!=1){
			return true;
		}
		return false;
	}
	
	
}