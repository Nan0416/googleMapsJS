import java.util.*;
import com.SnakePlay.*;
import com.SnakePlay.Map;
// food on snake
// food overlap
public class DriveMap{
    public static void main(String [] args){
        Map monitor=new Map();
        //
        int temp;
        Turn t=Turn.KEEP;
        Scanner in=new Scanner(System.in);
        int a=0;
        
        while(monitor.checkAlive()){
            //input dir;
            monitor.output2();
            a=in.nextInt();
            if(a==1){
                t=Turn.TURNLEFT;
            }else if(a==2){
                t=Turn.KEEP;
            }else if(a==3){
                t=Turn.TURNRIGHT;
            }
            //monitor.output2();
            monitor.setTurn(t);
            temp=monitor.checkEat();
            monitor.nextStatus(temp);
            
        }
        System.out.println("Game Over");
    }
}