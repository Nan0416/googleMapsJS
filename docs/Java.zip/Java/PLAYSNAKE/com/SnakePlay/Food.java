package com.SnakePlay;
public class Food{
    private int x;
    private int y;
    private int type;
    private String shape;
    private String color;
    private int size;
    public void setXY(int x,int y){
        this.x=x;
        this.y=y;
    }
    public void setType(int t){
        type=t;
    }
    public void setShapeColorSize(String shape,String color,int size){
        this.color=color;
        this.shape=shape;
        this.size=size;
    }
    Food(){
        x=y=0;
        type=1;
        color="red";
        shape="triangel";
        size=10;
    }
    public int getX(){return x;}
    public int getY(){return y;}
    public int getType(){return type;}
    public int getSize(){return size;}
    public String getShape(){return shape;}
    public String getColor(){return color;}

}