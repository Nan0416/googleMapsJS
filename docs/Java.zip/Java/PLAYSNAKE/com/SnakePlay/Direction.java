package com.SnakePlay;
public enum Direction{LEFT, UP,RIGHT,DOWN}