package com.SnakePlay;
public enum Turn {TURNLEFT, KEEP,TURNRIGHT}