package com.SnakePlay;

import java.util.*;
class BodyNode{
    private String color;
    private String shape;
    private int size;
    private int x;
    private int y;
    private boolean upbridge;
    private BodyNode last;
    private BodyNode next;
    private int bodyNo;
    public BodyNode(){
        color="blue";
        shape="circle";
        size=10;
        x=y=0;
        upbridge=false;
        last=next=null;
        bodyNo=0;
    }
    public BodyNode(int x,int y,int bodyNo,boolean up,BodyNode last,BodyNode next){
        this.x=x;
        this.y=y;
        this.bodyNo=bodyNo;
        this.upbridge=up;
        this.last=last;
        this.next=next;
        color="blue";
        shape="circle";
        size=10;
    }
    public void setX(int x){this.x=x;}
    public void setY(int y){this.y=y;}
    public void setColorShapeSize(String color,String shape,int size){
        this.color=color;
        this.shape=shape;
        this.size=size;
    }
    public void setBodyNo(int bodyNo){
        this.bodyNo=bodyNo;
    }
    public void setBodyNodeLast(BodyNode last){this.last=last;}
    public void setBodyNodeNext(BodyNode next){this.next=next;}
    public void setUpBridge(boolean up){upbridge=up;}
    
    public int getX(){return x;}
    public int getY(){return y;}
    public int getBodyNo(){return bodyNo;}
    public BodyNode getBodyNodeLast(){return last;}
    public BodyNode getBodyNodeNext(){return next;}
    public int getSize(){return size;}
    public String getColor(){return color;}
    public String getShape(){return shape;}
    public boolean getUpBridge(){return upbridge;}
    public void equals(BodyNode i){
        color=i.color;
        shape=i.shape;
        size=i.size;
        x=i.x;
        y=i.y;
        upbridge=i.upbridge;
        last=i.last;
        next=i.next;
        bodyNo=i.bodyNo;
    
    }

    
    
}// no semicolon