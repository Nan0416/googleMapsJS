package com.SnakePlay;
import java.util.Arrays;


class Snake{
    
    private int nodeNum;
    private Direction dir;
    private BodyNode []s;
    public Snake(){
        nodeNum=5;
        s=new BodyNode[nodeNum];
        
        //System.out.println(s[1].getY());
        for(int i=0;i<nodeNum;i++){
            s[i]=new BodyNode();
            s[i].setY(nodeNum-i-1);
            
            s[i].setX(0);
            
            s[i].setBodyNo(nodeNum-i);
            s[i].setUpBridge(false);
            if(i==0){
                s[i].setBodyNodeLast(null);
            }else{
                s[i].setBodyNodeLast(s[i-1]);
            }
            if(i==nodeNum-1){
                s[i].setBodyNodeNext(null);
            }else{
                s[i].setBodyNodeNext(s[i+1]);
            }
        }
        updateDir();
        
    }
        public void updateDir(){
            if(s[0].getX()==s[1].getX()){
                if(s[0].getY()==s[1].getY()-1){
                    dir=Direction.DOWN;
                }else if(s[0].getY()==s[1].getY()+1){
                    dir=Direction.UP;
                }else{
                    System.out.println("ERROR IN UPDATE DIR");
                }
            }else if(s[0].getY()==s[1].getY()){
                if(s[0].getX()==s[1].getX()-1){
                    dir=Direction.LEFT;
                }else if(s[0].getX()==s[1].getX()+1){
                    dir=Direction.RIGHT;
                }else{
                    System.out.println("ERROR IN UPDATE DIR");
                }
            
            }else{
                System.out.println("ERROR IN UPDATE DIR");
            }
        }
        public void setDir(Direction d){
            if(d==Direction.UP){
                dir=d;
            }else if(d==Direction.DOWN){
                dir=d;
            }else if(d==Direction.RIGHT){
                dir=d;
            }else if(d==Direction.LEFT){
                dir=d;
            }else{
                System.out.println("ERROR IN SET DIR");
            }
        }
        public void grow(int x,int y,boolean up){
            nodeNum++;
            BodyNode [] temp=s;
            s=new BodyNode[s.length+1];
            for(int i=0;i<nodeNum;i++){
                s[i]=new BodyNode();
            }
            s[0].setX(x);s[0].setY(y);
            s[0].setBodyNo(nodeNum+1);
            s[0].setUpBridge(up);
            for(int i=0;i<nodeNum-1;i++){
                s[i+1]=temp[i];
            }
            s[0].setBodyNodeLast(null);
            s[1].setBodyNodeLast(s[0]);
            s[0].setBodyNodeNext(s[1]);
           
            
        }
        public Direction getDir(){
            return dir;
        }
        public int getNodeNum(){
            return nodeNum;
        }
        public BodyNode[] getBodyNode(){return s;}
        
        

}