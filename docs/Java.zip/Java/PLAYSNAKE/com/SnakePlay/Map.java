package com.SnakePlay;
import java.util.*;
public class Map{
    
    private Snake s;
    private Food []f;
    private int foodNum;
    private int [] backGround;
    private int snakeLength;
    private void transfer(){
        BodyNode temp=s.getBodyNode()[0];
        if(temp.getX()>backGround[0]){
            temp.setX(temp.getX()-Math.abs(backGround[0])-Math.abs(backGround[1]));
        }
        if(temp.getY()>backGround[2]){
            temp.setY(temp.getY()-Math.abs(backGround[2])-Math.abs(backGround[3]));
        }
        if(temp.getX()<backGround[1]){
            temp.setX(temp.getX()+Math.abs(backGround[0])+Math.abs(backGround[1]));
        }
        if(temp.getY()<backGround[3]){
            temp.setY(temp.getY()+Math.abs(backGround[2])+Math.abs(backGround[3]));
        }
        
    }
    
    private Turn t;
    public void setTurn(Turn t){
        this.t=t;
    }
    public Map(){
        backGround=new int[]{10,-10,10,-10};//x,-x,y,-y
        int x;
        int y   ;
        s=new Snake();
        foodNum=5;
        f=new Food[foodNum];
        for(int i=0;i<foodNum;i++){
            f[i]=new Food();
            x=(int)(Math.random()*(Math.abs(backGround[0])+Math.abs(backGround[1]))-Math.abs(backGround[1]));
            y=(int)(Math.random()*(Math.abs(backGround[2])+Math.abs(backGround[3]))-Math.abs(backGround[3]));
            f[i].setXY(x,y);
            //System.out.println(x+" "+y);
        }
        snakeLength=s.getNodeNum();
        t=Turn.KEEP;//
    }
    public boolean checkAlive(){
        BodyNode[] temp=s.getBodyNode();
        for(int i=1;i<s.getNodeNum();i++){
            if(temp[0].getX()==temp[i].getX()&&temp[0].getY()==temp[i].getY()){
                return false;
            }
        }
        return true;
    }
    private void nextPositionUnEaten(){
        BodyNode[] temp=s.getBodyNode();
        if(t==Turn.KEEP){
            if(s.getDir()==Direction.UP){
                for(int i=s.getNodeNum()-1;i>0;i--){
                    temp[i].equals(temp[i-1]);
                }
                temp[0].setY(temp[0].getY()+1);
            }else if(s.getDir()==Direction.DOWN){
                for(int i=s.getNodeNum()-1;i>0;i--){
                    temp[i].equals(temp[i-1]);
                }
                temp[0].setY(temp[0].getY()-1);
            
            }else if(s.getDir()==Direction.LEFT){
                for(int i=s.getNodeNum()-1;i>0;i--){
                    temp[i].equals(temp[i-1]);
                }
                temp[0].setX(temp[0].getX()-1);
            }else if(s.getDir()==Direction.RIGHT){
                for(int i=s.getNodeNum()-1;i>0;i--){
                    temp[i].equals(temp[i-1]);
                }
                temp[0].setX(temp[0].getX()+1);
            }else{
                System.out.println("ERROR IN MAP NEXTPOSITION");
            }
            
        }else if(t==Turn.TURNLEFT){
            if(s.getDir()==Direction.UP){
                for(int i=s.getNodeNum()-1;i>0;i--){
                    temp[i].equals(temp[i-1]);
                }
                temp[0].setX(temp[0].getX()-1);
            }else if(s.getDir()==Direction.DOWN){
                for(int i=s.getNodeNum()-1;i>0;i--){
                    temp[i].equals(temp[i-1]);
                }
                temp[0].setX(temp[0].getX()+1);
                
            }else if(s.getDir()==Direction.LEFT){
                for(int i=s.getNodeNum()-1;i>0;i--){
                    temp[i].equals(temp[i-1]);
                }
                temp[0].setY(temp[0].getY()-1);
            }else if(s.getDir()==Direction.RIGHT){
                for(int i=s.getNodeNum()-1;i>0;i--){
                    temp[i].equals(temp[i-1]);
                }
                temp[0].setY(temp[0].getY()+1);
            }else{
                System.out.println("ERROR IN MAP NEXTPOSITION");
            }
        }else if(t==Turn.TURNRIGHT){
            if(s.getDir()==Direction.UP){
                for(int i=s.getNodeNum()-1;i>0;i--){
                    temp[i].equals(temp[i-1]);
                }
                temp[0].setX(temp[0].getX()+1);
            }else if(s.getDir()==Direction.DOWN){
                for(int i=s.getNodeNum()-1;i>0;i--){
                    temp[i].equals(temp[i-1]);
                }
                temp[0].setX(temp[0].getX()-1);
                
            }else if(s.getDir()==Direction.LEFT){
                for(int i=s.getNodeNum()-1;i>0;i--){
                    temp[i].equals(temp[i-1]);
                }
                temp[0].setY(temp[0].getY()+1);
            }else if(s.getDir()==Direction.RIGHT){
                for(int i=s.getNodeNum()-1;i>0;i--){
                    temp[i].equals(temp[i-1]);
                }
                temp[0].setY(temp[0].getY()-1);
            }else{
                System.out.println("ERROR IN MAP NEXTPOSITION");
            }
        }else{
            System.out.println("ERROR IN MAP NEXTPOSITION");
        }
        s.updateDir();
        transfer();
    }
    private void nextPositionEaten(){
        //s.grow();
        BodyNode temp=s.getBodyNode()[0];
        int x=temp.getX();
        int y=temp.getY();
        if(t==Turn.KEEP){
            if(s.getDir()==Direction.UP){
                 s.grow(x,y+1,false);
            }else if(s.getDir()==Direction.DOWN){
                s.grow(x,y-1,false);
            }else if(s.getDir()==Direction.LEFT){
                s.grow(x-1,y,false);
            }else if(s.getDir()==Direction.RIGHT){
                s.grow(x+1,y,false);
            }else{
                System.out.println("ERROR IN MAP NEXTPOSITION");
            }

        }else if(t==Turn.TURNLEFT){
            if(s.getDir()==Direction.UP){
                s.grow(x-1,y,false);
            }else if(s.getDir()==Direction.DOWN){
                s.grow(x+1,y,false);
            }else if(s.getDir()==Direction.LEFT){
                s.grow(x,y-1,false);
            }else if(s.getDir()==Direction.RIGHT){
                s.grow(x,y+1,false);
            }else{
                System.out.println("ERROR IN MAP NEXTPOSITION");
            }
        }else if(t==Turn.TURNRIGHT){
            if(s.getDir()==Direction.UP){
                s.grow(x+1,y,false);
            }else if(s.getDir()==Direction.DOWN){
                s.grow(x-1,y,false);
            }else if(s.getDir()==Direction.LEFT){
                s.grow(x,y+1,false);
            }else if(s.getDir()==Direction.RIGHT){
                s.grow(x,y-1,false);
            }else{
                System.out.println("ERROR IN MAP NEXTPOSITION");
            }
        }else{
            System.out.println("ERROR IN MAP NEXTPOSITION");
        }
        s.updateDir();
        transfer();
    }
    public int checkEat(){
    //return the index which food was eaten
    //else return -1;
        BodyNode temp=s.getBodyNode()[0];
        for(int i=0;i<foodNum;i++){
            if(temp.getX()==f[i].getX()&&temp.getY()==f[i].getY()){
                return i;
            }
        }
        return -1;
    
    }
    public void updateFood(int i){
        f[i].setXY((int)(Math.random()*(Math.abs(backGround[0])+Math.abs(backGround[1]))-Math.abs(backGround[1])),(int)(Math.random()*(Math.abs(backGround[2])+Math.abs(backGround[3]))-Math.abs(backGround[3])));
    }
    public void nextStatus(int index){
        if(index<0){
        // no food was eaten
            nextPositionUnEaten();
        }else{
            
            updateFood(index);
            nextPositionEaten();
            
        }
    }
    public void output(){
        BodyNode temp=s.getBodyNode()[0];
        System.out.print("Food ");
        for(int i=0;i<foodNum;i++){
            System.out.print("("+f[i].getX()+", "+f[i].getY()+") ");
        }
        System.out.println("\n("+temp.getX()+", "+temp.getY()+") @ length "+s.getNodeNum());
    }
    public void output2(){
        BodyNode [] temp=s.getBodyNode();
        System.out.print("Food ");
        for(int i=0;i<foodNum;i++){
            System.out.print("("+f[i].getX()+", "+f[i].getY()+") ");
        }
        System.out.println();
        for(int i=0;i<s.getNodeNum();i++){
            System.out.print("("+temp[i].getX()+", "+temp[i].getY()+")");
        }
        System.out.println(" @ lenght"+s.getNodeNum());
    
    
    }
}