package com.qinnan.logger;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class logger {
	public static void main(String [] args){
		
		Logger.getGlobal().info("File->Opened");
		//Logger.getGlobal().setLevel(Level.OFF);
		//will off the below info()
		//it is like in different layer
		Logger.getGlobal().info("File->Global info");
		Logger.getGlobal().fine("File->Global fine");
		Logger mylogger=Logger.getLogger("com.qinnan.some");
		mylogger.setLevel(Level.ALL);
		mylogger.info("File->mylogger info");
		mylogger.fine("File->mylogger fine");
		mylogger.log(Level.SEVERE,"Severe level");
		mylogger.log(Level.WARNING,"WARING level");
		mylogger.log(Level.FINER,"FINER level");
		mylogger.logp(Level.WARNING, "String", "getClass", "costomized");
		mylogger.severe("Severe");
		int i=12;
		try{
			if(i>10){
				IOException e=new IOException();
				mylogger.throwing(String.class.getName(), "Main", e);
				throw e;
			}
		}catch(Exception e){
			System.out.println("Try");
			mylogger.log(Level.WARNING,"msg",e);
		}
	}
	
}
