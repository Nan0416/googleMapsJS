package com.qinnan.list;

import java.util.logging.Logger;
import java.io.File;
public class Search {
    private static int ii=0;
    private static boolean flag1=false;
    private static String search="";
	public static void main(String [] args){
		
		if(args.length<1){
			Logger.getGlobal().info("Argument Error");
			System.exit(0);
		}
        for(int i=1;i<args.length;i++){
            if(i==1&&args[1]=="-h"){
                flag1=true;
            }
            if(i==2){
            	
                search=args[2];
            }
        }
        String dir=args[0];
        
        System.out.println(dir);

		File file=new File(dir);
		if(!file.exists()){
			System.out.println(dir+" does not exist!");
		}
		if(file.isFile()){
			System.out.println(dir);
		}
		if(file.isDirectory()){
			String [] m=file.list();
            
			search(m,dir);
		}
		
	}
	private static void search(String [] m,String father){
       
		for(int i=0;i<m.length;i++){
            
			File file=new File(father+File.separatorChar+m[i]);
            
			if(file.isFile()){
                if(search==""){
                	
                    if(!file.isHidden()){
                        System.out.println(father+File.separatorChar+m[i]);
                    }else if(flag1){
                        System.out.println(father+File.separatorChar+m[i]);
                    }
                }else{
                	//System.out.println("do");
                    if(match(m[i],search)){
                        if(!file.isHidden()){
                            System.out.println(father+File.separatorChar+m[i]);
                        }else if(flag1){
                            System.out.println(father+File.separatorChar+m[i]);
                        }
                    }
                }
				
			}
			if(file.isDirectory()){
				String [] n=file.list();
				search(n,father+File.separatorChar+m[i]);
			}
		}
	}
    private static boolean match(String hu1,String hu2){
        if(hu2.length()>hu1.length()){
            return false;
        }else{
            for(int i=0;i<hu1.length()-hu2.length();i++){
                if(hu1.substring(i,i+hu2.length()).equals(hu2)){
                	
                    return true;
                }
            }
        }
        return false;
    }
}
