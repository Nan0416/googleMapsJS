package com.qinnan.src;

public class sub extends var{
	private int a;
	public sub(int a) {
		super(a);
		this.a = a;
	}
	public int getA() {
		return super.a;
	}
	public void setA(int a) {
		this.a = a;
	}
	
	

}
