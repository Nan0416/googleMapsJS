package com.qinnan.src;

public class drive {
	public static void main(String [] args){
		sub ji = new sub(10);
		//ji.a;
	}

}
