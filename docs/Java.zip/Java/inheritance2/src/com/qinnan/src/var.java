package com.qinnan.src;

public class var {
	public int a;
	public var(int a){
		this.a = a;
		
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}

}
