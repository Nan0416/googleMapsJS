import com.qinnan.Final.*;
public class FinalPhoneDrive{
    public static void main(String [] args){
        FinalPhone f=new FinalPhone();
        f.output();
        FinalPhone f2=new FinalPhone(911,"AT&T",-12.23);
        f2.output();
        Inheritance f3=new Inheritance(110,"ChinaUnion",123.03,"Unknown");
        f3.output();
        FinalPhone f4=new Inheritance(120,"ChinaMobile",235.21,"Me");
        f4.output();//dynamic binding
        System.out.println(f4 instanceof Inheritance);
        FinalPhone f5=(FinalPhone)f4;
        f5.output();
        System.out.println(f5 instanceof Inheritance);
        FinalPhone f6;
        f6=new Inheritance(119,"ChinaTele",102.023,"Who cares");
        f6.output();
        System.out.println(f6 instanceof Inheritance);
        FinalPhone [] a=new FinalPhone[4];
        for(int i=0;i<2;i++){
            a[i]=new FinalPhone();
        }
        for(int i=2;i<4;i++){
            a[i]=new Inheritance();
        }
        for(int i=0;i<4;i++){
            a[i].output();
            System.out.println("==============="+(a[i] instanceof Inheritance));
        }
        FinalPhone f7=(FinalPhone) a[3];
        System.out.println("=f7============="+(f7 instanceof Inheritance));
        f7.output();
        ((Inheritance)f7).out2();
        //f3.out();
        f3.out2();
        f3.test1();
        //f7.test1();
        ((Inheritance)f7).test1();
        // for the method that both super class and child class have is via binding
        //for the method that child class has but super class doesn't,
        
        //Super class instance cannot use that, even is base a= new child;
        // but if you use the instanceof, it will show you the it belongs to child
    }
    
}