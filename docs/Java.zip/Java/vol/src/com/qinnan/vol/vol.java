package com.qinnan.vol;

public class vol {
	private volatile int i;
	public vol(){
		i=0;
	}
	public Runnable run1(){
		return new Runnable(){
			public void run(){
				i++;
				System.out.println(i);
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				i++;
				System.out.println(i);
			}
		};
	}
	public Runnable run2(){
		return new Runnable(){
			public void run(){
				i++;
				System.out.println("Run2 "+i);
			}
		};
	}
}
