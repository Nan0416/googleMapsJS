package com.qinnan.vol;

public class dri {
	public static void main(String [] args){
		vol n=new vol();
		for(int i=0;i<1000;i++){
			Thread t1=new Thread(n.run1());
			Thread t2=new Thread(n.run2());
			t1.start();
			try {	
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			t2.start();
		}
	}
		
}

