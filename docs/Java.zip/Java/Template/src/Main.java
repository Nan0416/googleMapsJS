
public class Main {
	public static void main(String [] args){
		Sequence<String> s = new Sequence<String>();
		Sequence<Sequence<String>> s2 = new Sequence();
		System.out.println(s2.getClass()+"   "+s.getClass());
	
	}

}
