
class Sequence <Base>{
	private int i = 10;

}


