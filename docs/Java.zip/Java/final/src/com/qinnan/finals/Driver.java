package com.qinnan.finals;

public class Driver {
	public static void main(String [] args){
//		int [] integers = {1,2,3,4,5,6,7,8,9,10};
//		String [] strings = new String [10];
//		for(int i = 0; i < strings.length; i++){
//			strings[i] = "this is "+i;
//		}
//		for(int i: integers){
//			i = i + 1;
//		}
//		for(String j: strings){
//			j += ".";
//		}
//		for(int i = 0; i < integers.length; i++){
//			System.out.println(integers[i] + " > " + strings[i]);
//		}
//		
//		
		AssociationList<String, Integer> ss = new AssociationList();
		ss.add("one",1);
		ss.add("two",2);
		ss.printall(ss);
		ss.printall(ss.inverse());
		
	}

}
class AssociationList<Key, Value>{
	private class Node{
		private Key key;
		private Value value;
		private Node next;
		private Node(Key key, Value value, Node next){
			this.key = key;
			this.value = value;
			this.next = next;
		}
	}
	private Node head = null;
	public void add(Key key, Value value){
		head = new Node(key, value, head);
	}
	public AssociationList<Value, Key> inverse(){
		AssociationList<Value, Key> result = new AssociationList<Value, Key>();
		Node temp = head;
		while(head != null){
			result.add(head.value, head.key);
			head = head.next;
		}
		return result;
	}
	public void printall(AssociationList rs){
		Node temp = rs.head;
		while(temp != null){
			System.out.println(temp.key + " " + temp.value);
			temp = temp.next;
		}
		
	}
	
	
}