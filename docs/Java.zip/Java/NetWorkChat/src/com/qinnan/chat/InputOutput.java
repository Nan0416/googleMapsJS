package com.qinnan.chat;

import java.io.PrintWriter;
import java.util.Scanner;

public class InputOutput {
	public Runnable input(Scanner in){
		return new Runnable(){
			public void run(){
				while(in.hasNextLine()){
					System.out.println(in.nextLine());
				}
			}
		};
	}
	public Runnable output(PrintWriter out){
		return new Runnable(){
			public void run(){
				Scanner in=new Scanner(System.in);
				while(in.hasNextLine()){
					out.println(in.nextLine());
				}
			}
		};
	}
}
