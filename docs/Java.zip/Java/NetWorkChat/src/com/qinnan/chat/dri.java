package com.qinnan.chat;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.Scanner;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
public class dri {
	public static void main(String [] args) throws IOException{
		byte [] ThinkPadUbuntuAddress=new byte[]{(byte)192,(byte)168,(byte)19,(byte)11};
		InetAddress ThinkPad=InetAddress.getByAddress(ThinkPadUbuntuAddress);
		System.out.println(ThinkPad.isReachable(10000));
		Socket ThinkPadServer=new Socket();
		InetSocketAddress ThinkPadAddress=new InetSocketAddress("192.168.19.11",8920);
		ThinkPadServer.connect(ThinkPadAddress, 10000);
		ThinkPadServer.setSoTimeout(10000);
		InputStream networkIn =ThinkPadServer.getInputStream();
		OutputStream networkOut=ThinkPadServer.getOutputStream();
		Scanner in=new Scanner(networkIn);
		
		//print to network
		PrintWriter out=new PrintWriter(networkOut,true);
		InputOutput io=new InputOutput();
		Thread input=new Thread(io.input(in));
		Thread output=new Thread(io.output(out));
		input.start();
		output.start();
	}
}
