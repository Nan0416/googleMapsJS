package com.qinnan.doc;
/**
 * A class comments <em>must</em> after import statements, directly before class
 * @author Nan Qin
 *  hello arbitrary tag is allowed, but will error
  	this is valid to omit the * before each line.
 * 
 */

public class doc {
	/**
	 * initial with 0
	 */
	public int hu = 0;
	/**
	 * this is a demo method
	 * @param hu
	 * integer
	 * @return 1
	 * something
	 * @throws Exception
	 * sss
	 * 
	 */
	public int play(int hu){
		if(hu>10){
			
		}
		return 1;
	}
	/**
	 * @deprecated do not use
	 */
	protected void hello(){
		
	}
	/**
	 * @see also see <a href = "http://www.google.com"> Other </a>
	 */
	public void huww(){
		
	}
	/**
	 * @see "see also section with "
	 */
	public void ww(){
		
	}
	/**
	 * {@link com.qinnan.doc.doc2#location()}
	 */
	public void we(){
		
	}
}
