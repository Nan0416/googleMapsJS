package com.qinnan.doc;

public class doc2 {
	public void location(){
		
	}

}
