package com.qinnan.sorting;

public class Sorting {
	
	public void insertion(int [] array){
		for(int i = 1; i < array.length; i++){
			int temp = array[i];
			int index = i - 1;
			while(index >= 0 && temp < array[index]){
				array[index + 1] = array[index];
				index -= 1;
			}
			array[index + 1] = temp;
		}
	}
	public void quicksort(int [] array){
		quicksort(array, 0, array.length-1);
		
	}
	private void quicksort(int [] array, int leftEnd, int rightEnd){
		int left = leftEnd;
		int right = rightEnd;
		int pivot = array[(leftEnd + rightEnd)/2];
		do{
			while(array[left] < pivot){
				left += 1;
			}
			while(array[right] > pivot){
				right -= 1;
			}
			if(left <= right){
				int temp = array[left];
				array[left] = array[right];
				array[right] = temp;
				left += 1;
				right -= 1;
			}
		}while(left <= right);
		
		if(leftEnd < right){
			quicksort(array, leftEnd, right);
		}
		if(rightEnd > left){
			quicksort(array, left, rightEnd);
		}
		
	}
}
