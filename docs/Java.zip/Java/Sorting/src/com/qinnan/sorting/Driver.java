package com.qinnan.sorting;

public class Driver {
	public static void main(String [] args){
		Sorting sort = new Sorting();
		int [] array = {4,5,2,3,7,1,9,2,3,6,32,6,3,4,8,5,6,2,3,8,3,54,1,0};
		int [] b = array.clone();
		printarray(array);
		sort.insertion(array);
		printarray(array);
		printarray(b);
		sort.quicksort(b);
		printarray(b);
		
	}
	public static void printarray(int [] array){
		for(int i: array){
			System.out.print(i+ " ");
		}
		System.out.println();
	}

}
