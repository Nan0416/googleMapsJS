package com.qinnan.lab13;

import java.io.FileReader;   //  Read Unicode chars from a file.
import java.io.IOException;  //  In case there's IO trouble.

public class qinxx232_lab13 {
	public static void main(String [] args){
		 HashTable bitwiseTable     = new HashTable(769, new BitwiseHasher());  
		 HashTable javaTable        = new HashTable(769, new JavaHasher());  
		 HashTable lengthTable      = new HashTable(769, new LengthHasher());  
		 HashTable sumTable         = new HashTable(769, new SumHasher());  
		 HashTable thirtySevenTable = new HashTable(769, new ThirtySevenHasher());  
		  
		 Words words = new Words("hackers");  
		 while (words.hasNext())  
		 {  
		      String word = words.next();  
		      bitwiseTable.add(word);  
		      lengthTable.add(word);  
		      javaTable.add(word);  
		      sumTable.add(word);  
		      thirtySevenTable.add(word);  
		 }  
		  
		 bitwiseTable.writeStatistics("BitwiseTable");  
		 javaTable.writeStatistics("JavaTable");  
		 lengthTable.writeStatistics("LengthTable");  
		 sumTable.writeStatistics("SumTable");  
		 thirtySevenTable.writeStatistics("ThirtySevenTable");  
	}
}

class HashTable{
	private class Node {
		private String key;
		private Node next;
		private Node (String key, Node next){
			this.key = key;
			this.next = next;
		}
	}
	private Node hash_table [];
	private Hasher hasher;
	public HashTable(int size, Hasher hasher){
		this.hasher = hasher;
		hash_table = new Node[size];
	}
	public void add(String key){
		int index = hash(key);
		hash_table[index] = new Node(key, hash_table[index]);
	}
	public int keysAt(int index){
		int result = 0;
		Node temp = hash_table[index];
		while(temp != null){
			temp = temp.next;
			result += 1;
		}
		return result;
	}
	private int hash(String key){
		return hasher.hash(key) % hash_table.length;
	}
	public void writeStatistics(String title){
		System.out.println("==========   " + title + "   ==========");
		int collision = 0;
		int smallest_non_empty_bucket = 0;
		int largest_non_empty_bucket = 0;
		int smallest_index = 0;
		int largest_index = 0;
		boolean flag = false;
		for(int i = 0; i < hash_table.length; i += 1){
			int temp = keysAt(i);
			if(temp > 1){
				collision += 1;
			}
			if(temp > 0 && !flag){
				smallest_non_empty_bucket = temp;
				smallest_index = i;
				flag = true;
			}
			if(temp > 0 && temp < smallest_non_empty_bucket && flag){
				smallest_non_empty_bucket = temp;
			}
			if(temp > largest_non_empty_bucket){
				largest_non_empty_bucket = temp;
			}
			if(temp > 0){
				largest_index = i;
			}
		}
		System.out.println("1. Number of collided buckets: " + collision);
		System.out.println("2. The length of the smallest non empty bucker: " + smallest_non_empty_bucket);
		System.out.println("3. The length of the largest nonempty bucket: " + largest_non_empty_bucket);
		System.out.println("4. The smallest index of a nonempty bucket: " + smallest_index);
		System.out.println("5. The largest index of a nonempty bucket: " + largest_index);
		
	}
	
	
}



//
//HASHER. Example hash functions for STRINGs.
//
//James B. Moen
//23 Apr 15
//

//HASHER. A class whose instances provide a hash method HASH for STRINGs.

class Hasher{
	public int hash(String key){
		return 0;
	}
}

//BITWISE HASHER. A bitwise hash method.

class BitwiseHasher extends Hasher{
	public int hash(String key){
		int bits = 0;
		for (int index = 0; index < key.length(); index += 1){
			bits = (bits << 1) ^ key.charAt(index);
		}
	return bits;
	}
}

//JAVA HASHER. Java's HASH CODE method.

class JavaHasher extends Hasher{
	public int hash(String key){
		return key.hashCode();
	}
}

//LENGTH HASHER. Use the length of KEY as a hash code.

class LengthHasher extends Hasher{
	public int hash(String key){
		return key.length();
	}
}

//SUM HASHER. A hash method that returns the sum of the CHARs of KEY.

class SumHasher extends Hasher{
	public int hash(String key){
		int sum = 0;
		for (int index = 0; index < key.length(); index += 1){
			sum += key.charAt(index);
		}
		return sum;
	}
}

//THIRTY SEVEN HASHER. A hash method that computes a base 37 polynomial whose
//coefficients are the CHARs of KEY.

class ThirtySevenHasher extends Hasher{
	public int hash(String key){
		int sum = 0;
		for (int index = 0; index < key.length(); index += 1){
			sum = 37 * sum + key.charAt(index);
		}
		return sum;
	}
}

//
//WORDS. An iterator that reads words from a text file.
//
//James Moen
//15 Mar 15
//



//WORDS. Iterator. Read words, represented as STRINGs, from a text file. Each
//word is the longest possible contiguous series of non-whitespace CHARs.

class Words{
	private int ch;      //  Last CHAR from READER, as an INT.
	private FileReader reader;  //  Read CHARs from here.
	private StringBuilder word;    //  Last word read from READER.

//Constructor. Initialize an instance of WORDS, so it reads words from a file
//whose pathname is PATH. Throw an exception if we can't open PATH.

	public Words(String path){
		try{
			reader = new FileReader(path);
			ch = reader.read();
		}catch (IOException ignore){
			throw new IllegalArgumentException("Cannot open '" + path + "'.");
		}
	}

//HAS NEXT. Try to read a WORD from READER. Test if we were successful.

	public boolean hasNext(){
		word = new StringBuilder();
		while (ch > 0 && Character.isWhitespace((char) ch)){
			read();
		}
		while (ch > 0 && ! Character.isWhitespace((char) ch)){
			word.append((char) ch);
			read();
		}
		return word.length() > 0;
	}

//NEXT. If HAS NEXT is true, then return a WORD read from READER as a STRING.
//Otherwise, return an undefined STRING.

	public String next(){
		return word.toString();
	}

//READ. Read the next CHAR from READER. Set CH to the CHAR, represented as an
//INT. If there are no more CHARs to be read from READER, then set CH to -1.

	private void read(){
		try{
			ch = reader.read();
		}catch (IOException ignore){
			ch = -1;
		}
	}

//MAIN. For testing. Open a text file whose pathname is the 0th argument from
//the command line. Read words from the file, and print them one per line.

	public static void main(String [] args){
		Words words = new Words(args[0]);
		while (words.hasNext()){
			System.out.println("'" + words.next() + "'");
		}
	}
}