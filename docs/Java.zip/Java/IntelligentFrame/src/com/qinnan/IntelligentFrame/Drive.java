package com.qinnan.IntelligentFrame;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.Ellipse2D;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;

public class Drive {
	public static void main(String [] args){
		RUN myrun=new RUN();
		Thread t1=new Thread(myrun.run1());
		Thread t2=new Thread(myrun.run2());
		boolean flag=true;
		do{
			if(flag){
				t1.start();
				flag=false;
			}
		}while(!(t1.getState()==Thread.State.TERMINATED));
		t2.start();
	}
	private JFrame window(){
		//Toolkit tool=new Toolkit();
				Toolkit tool=Toolkit.getDefaultToolkit();
				Dimension screenSize=tool.getScreenSize();
				JFrame window=new JFrame("Nan Qin");
				window.setSize(screenSize.width/2, screenSize.height/2);
				window.setLocationByPlatform(true);
				window.setAlwaysOnTop(true);
				
				Image icon=new ImageIcon("/Users/hatakunsoki/Desktop/images.gif").getImage();
				//does not work//maybe caused by operating system
				window.setIconImage(icon);
				
				
				//
				Container contentPane=window.getContentPane();
				Component comp=getComp1();
				contentPane.add(comp);
				//guess
				//add call comp method
				//to trigger the method new a Graphics and then call the paintComponent(g)
				
				//
				//window.pack();
				
				window.setVisible(true);
				
				try{
					window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				}catch(SecurityException e){
					e.printStackTrace();
				}
				return window;
		}	
	private Component getComp1(){
		return new JComponent(){
			public void paintComponent(Graphics g){
				//Toolkit tool=Toolkit.getDefaultToolkit();
				//Dimension screenSize=tool.getScreenSize();
				//wrong
				//this method is call by other 
				g.drawString("Nan Qin",100,200);
				//draw 2D
				/*
				 * Graphics 2D is a subclass of Graphics
				 * but here you can use
				 * Graphics2D d2=(Graphics2D)g;
				 * this is because since java se2.0 the g is actual a graphics2D object
				 */
				Graphics2D d2=(Graphics2D) g;
				//shape as class
				/*
				 * such classes as, Line2D,Rectangle2D,Ellipse2D all implements Shape interface
				 * 
				 */
				Ellipse2D ell=new Ellipse2D.Double(10,10,10,10);
				d2.draw(ell);
				
			}
			public Dimension getPreferredSize(){
				return new Dimension(200,200);
				//return the g size;
			}
		};
	}
}
class RUN{
	JFrame window=new JFrame("Nan Qin");
	Image i=new ImageIcon("images.gif").getImage();
	public Runnable run1(){
		return new Runnable(){

			@Override
			public void run() {
				Toolkit tool=Toolkit.getDefaultToolkit();
				Dimension screenSize=tool.getScreenSize();
				
				window.setSize(screenSize.width/2, screenSize.height/2);
				window.setLocationByPlatform(true);
				window.setAlwaysOnTop(true);
				
				Image icon=new ImageIcon("images.gif").getImage();
				//does not work//maybe caused by operating system
				window.setIconImage(icon);
				
				
				//
				Container contentPane=window.getContentPane();
				Component comp=getComp1();
				contentPane.add(comp);
				//guess
				//add call comp method
				//to trigger the method new a Graphics and then call the paintComponent(g)
				
				//
				//window.pack();
				
				window.setVisible(false);
				
				try{
					window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				}catch(SecurityException e){
					e.printStackTrace();
				}
				
			}
			
		};
		
	}
	public Runnable run2(){
		return new Runnable(){
			public void run(){
				window.setVisible(true);
			}
		};
	}
	private Component getComp1(){
		return new JComponent(){
			public void paintComponent(Graphics g){
				//Toolkit tool=Toolkit.getDefaultToolkit();
				//Dimension screenSize=tool.getScreenSize();
				//wrong
				//this method is call by other 
				g.drawString("Nan Qin",100,200);
				Graphics2D d2=(Graphics2D) g;
				Ellipse2D ell=new Ellipse2D.Double(200,210,300,150);
				d2.setPaint(Color.RED);
				d2.fill(ell);
				//d2.draw(ell);
				d2.drawImage(i,100,100, null);
				g.draw3DRect(30, 100, 40, 34, false);
				
				
			}
			public Dimension getPreferredSize(){
				return new Dimension(200,200);
				//return the g size;
				
			}
		};
	}
}

