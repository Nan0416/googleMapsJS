package com.qinnan.number;
import java.lang.Integer;
public class Drive {
	public static void main(String [] args){
		Integer i= new Integer(101);
		Integer j =new Integer("101");
		System.out.println(Integer.MAX_VALUE + " " + i + " " + j);
		int k = i.intValue();
		int l = j;
		//autoboxing;
		int  m = Integer.MAX_VALUE;
		int n = Integer.reverse(m);
		// bit revers
		// 011101 -- 101110
		System.out.println(m + " " + n);
		
		
		
	}

}
