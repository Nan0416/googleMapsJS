package com.qinnan.database;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
//import com.mysql.jdbc.Driver;
public class Drive {
//	private static String url="jdbc:mysql://192.168.19.11:3306/NanQin";
//	private static String user="hatakusunoki";
//	private static String password="QN1994qn";
	public static void main(String [] args) throws ClassNotFoundException, SQLException{
		Operation op=new Operation("192.168.19.11","hatakusunoki","Company");
		op.DMLRead("Select * from staff");
		op.printResult();
		op.close();
		
		
		
		
		
	/*	// add driver (reflect)
		Class.forName("com.mysql.jdbc.Driver");
		// connect
		Connection conn=(Connection) DriverManager.getConnection(url, user, password);
		//
		Statement stmt=(Statement) conn.createStatement();
		ResultSet rs=stmt.executeQuery("select name from instructor");
		while(rs.next()){
			System.out.println(rs.getString("name"));
		}*/
		
	}

}
