package com.qinnan.database;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.mysql.jdbc.Connection;
public class Operation {
	private Connection conn;
	private Statement stat;
	private String url;
	private String username;
	private String password;
	private ResultSet rs;
	private Statement getConnection(String address,String username,String databaseName) throws SQLException{
		//"jdbc:mysql://192.168.19.11:3306/NanQin"
		url="jdbc:mysql://"+address+":3306/"+databaseName;
		this.username=username;
		System.out.print("Enter password: ");
		Scanner in=new Scanner(System.in);
		password=in.next();
		return ((Connection) DriverManager.getConnection(url, username,password)).createStatement();
		//return ;
	}
	public Operation(String address,String username,String databaseName)throws SQLException {
		stat=getConnection(address,username,databaseName);
	}
	public int DMLWriteAndDDL(String sql) throws SQLException{
		// INSERT, UPDATE, and DELETE,
		return stat.executeUpdate(sql);
	}
	public ResultSet DMLRead(String sql) throws SQLException{
		//select
		return rs=stat.executeQuery(sql);
		
	}
	public void printResult() throws SQLException{
		while(rs.next()){
			for(int i=1;i<=12;i++){
				System.out.print(rs.getString(i)+" ");
			}
			System.out.println();
		}
	}
	public void close() throws SQLException{
		stat.close();
		//conn.close();
	}
	
}
