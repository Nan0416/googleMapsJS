package abs;


public class qinan {
	public static void main(String [] args){
		int x = 0x80000000;
		System.out.println(x + " " + abs(x) + " " + Math.abs(x));
		StringBuffer temp = new StringBuffer();
		temp.append("qinnan");
		System.out.println(temp.toString());
		
	}
	public static int abs(int x){
		if (x < 0){
			return x * -1;
		}else{
			return x;
		}
	}

}
