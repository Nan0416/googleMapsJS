package com.qinnan.bank;

public class dri {
	private final static int UserNumber=300;
	private final static double Money=100000.00;
	public static void main(String [] args){
		Bank bank=new Bank(UserNumber,Money);
		Thread [] t=new Thread[UserNumber];
		for(int i=0;i<UserNumber;i++){
			t[i]=new Thread(new PersonRunnable(bank));
			boolean flag=true;
			
			t[i].start();
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
}
