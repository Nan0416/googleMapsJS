package com.qinnan.bank;

import java.util.logging.Logger;

public class PersonRunnable implements Runnable{
	public static int total=0;
	public final int no;
	public Bank bank;
	public PersonRunnable(Bank bank){
		this.bank=bank;
		no=total++;
	}
	public void run(){
		int to=(int) (bank.getUsersNumber()*Math.random());
		if(to==100){
			Logger.getGlobal().info("=========");
		}
		double money=bank.getMoney(no)*Math.random();
		if(no==100){
			Logger.getGlobal().info("+++++++++");
		}
		bank.transfer(no,to,money);
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.printf("transfer %10.2f from %d to %d, total %10.2f\n",money,no,to,bank.totalmoney());
	}

}
