package com.qinnan.bank;

import java.util.logging.Logger;

public class Bank {
	int usersnumber;
	double [] accounts;
	double total;
	public Bank(int usersnumber,double [] accounts){
		this.usersnumber=usersnumber;
		this.accounts=accounts;
	}
	public Bank(int usersnumber,double inti){
		this.usersnumber=usersnumber;
		accounts=new double[usersnumber];
		for(int i=0;i<usersnumber;i++){
			accounts[i]=inti;
		}
	}
	public void transfer(int from, int to, double ammount){
		assert from>0&&from<=usersnumber;
		assert to>0&&to<=usersnumber;
		if(ammount<0||ammount>accounts[from]){
			return;
		}else{
			accounts[from]-=ammount;
			//System.out.println("reduced");
			accounts[to]+=ammount;
			//System.out.println("Added");
		}
	}
	public double totalmoney(){
		total=0;
		for(int i=0;i<usersnumber;i++){
			total+=accounts[i];
		}
		return total;
	}
	public int getUsersNumber(){
		return usersnumber;
	}
	public double getMoney(int no){
		double t=0;
		try{
			t=accounts[no];
		}catch(Exception e){
			Logger.getGlobal().info(no+"");
			
			
		}
		return t;
	}
}
