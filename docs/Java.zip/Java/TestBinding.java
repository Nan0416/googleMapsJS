import com.qinnan.*;
public class TestBinding{
    public static void main(String [] args){
        Base [] a=new Base[4];
        for(int i=0;i<2;i++){
            a[i]=new Base();
        }
        for(int i=2;i<4;i++){
            a[i]=new Child();
        }
        for(int i=0;i<4;i++){
            a[i].out();
        }
        
        ((Child)a[3]).out2();
      /*  Base []o=new Child[1];
        o[0]=new Child();
        o[0].out2();*/
        Child [] o2=new Child[1];
        o2[0]=new Child();
        o2[0].out2();
        //Child d=a[3];
        //from father to child need casting
        Child d=(Child) a[3];
        d.out2();
        System.out.println(a[3] instanceof Base);
        System.out.println(a[3] instanceof Child);
        System.out.println(a[1] instanceof Base);
        System.out.println(a[1] instanceof Child);
        //Child e=(Child) a[1];
        //compiling doesn't record error, but running error will emerge
        //d.out();
        //e.out2();
        //d.out();
    }
}