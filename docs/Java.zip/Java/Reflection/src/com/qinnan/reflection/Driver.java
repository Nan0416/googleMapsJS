package com.qinnan.reflection;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import com.qinnan.tryreflaction.litterclass;
public class Driver {
	public static void main(String [] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchFieldException, SecurityException, NoSuchMethodException{
		//Object has a method called getClass()
		//return the runtime class of this object
		//# python __class__ attribute
		//a Class object describes the properties of a particular class
		String words = new String("Nan Qin");
		Class wordsClass = words.getClass();
		print(wordsClass);
		print(wordsClass.getName());
		Class wordsClass2 = Class.forName("java.lang.String");
		if (wordsClass == String.class){
			print("Yes");
		}
		if(words instanceof String){
			print("yes");
		}
		//Object io = Class.forName("com.qinnan.tryreflaction.litterclass").newInstance();
		//litterclass hu = new litterclass();
		//((litterclass) io).show();
		litterclass temp = new litterclass();
		Class c1 = temp.getClass();
		Field[] f1 = c1.getFields();
		for (Field i : f1){
			print(i.getName());
			Class cf1 = i.getType();
			print(cf1.getName());
		}
		Method m1 = c1.getMethod("set", Class.forName("java.lang.Integer"));
		Method [] m2 = c1.getDeclaredMethods();
		for (Method i: m2){
			print(i.getName());
		}
		print(m1.getName());
	}
	private static void print(Object o){
		System.out.println(o);
	}

}
