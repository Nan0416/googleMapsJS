package com.qinnan.parseString;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class Drive {
	public void Parse(Class c1) throws ClassNotFoundException{
		//Class c1 = Class.forName("com.qinnan.tryreflaction.litterclass");
		System.out.println("********Constructors**********");
		Constructor [] c = c1.getDeclaredConstructors();
		for (Constructor i :c){
			
			System.out.print(Modifier.toString(i.getModifiers()) + " " + i.getName() + " ");
			Class [] paras = i.getParameterTypes();
			for (Class para :paras){
				System.out.print(para.getName());
			}
			
			System.out.println();
			
		}
		System.out.println("********Fields**********");
		Field [] f = c1.getDeclaredFields();
		for (Field i :f){
			
			System.out.print(Modifier.toString(i.getModifiers()) + " " + i.getName() + " ");
			
			
			System.out.println();
			
		}
		System.out.println("********Methods**********");
		Method [] m = c1.getDeclaredMethods();
		for (Method i :m){
			
			System.out.print(Modifier.toString(i.getModifiers()) + " " + i.getName() + " ");
			Class [] paras = i.getParameterTypes();
			for (Class para :paras){
				System.out.print(para.getName());
			}
			
			System.out.println();
			
		}
	}
}
