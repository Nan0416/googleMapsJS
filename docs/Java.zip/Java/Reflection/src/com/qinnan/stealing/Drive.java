package com.qinnan.stealing;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import com.qinnan.tryreflaction.*;

public class Drive {
	public static void main(String [] args) throws ClassNotFoundException, IllegalArgumentException, IllegalAccessException{
		Class c1 = Class.forName("com.qinnan.tryreflaction.litterclass");
		Field [] fs = c1.getDeclaredFields();
		Field anal = null;
		for (Field i: fs){
			if (Modifier.isPrivate(i.getModifiers())){
				anal = i;
				break;
			}
			
		}
		anal.setAccessible(true);
		litterclass temp = new litterclass();
		Object o = anal.get(temp);
		System.out.println(o.toString());
		temp.show();
		anal.set(temp,"Hack");
		temp.show();
		
	}

}
