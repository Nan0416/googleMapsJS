package com.qinnan.tryreflaction;

public class litterclass {
	public int var = 0;
	private String str = "";
	public litterclass(int var){
		this.var = var;
		str = "intvar";
	}
	public litterclass(){
		var = 0;
		str = "nothing";
	}
	public void increment(){
		var++;
	}
	public void set(Integer i){
		var = i;
	}
	public void show(){
		System.out.println(str);
	}
	private void hidden(){
		var--;
	}
	
}
