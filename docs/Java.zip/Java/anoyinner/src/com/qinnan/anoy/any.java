package com.qinnan.anoy;

public class any {
	//Object th;
	public void out(){
		System.out.println("This is any out");
		//out3();
	}
	public void out2(){
		System.out.println("This is any out2");
	}
}
