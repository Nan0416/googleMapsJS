package com.qinnan.anoy;

public class Dri {
	public static void main(String [] args){
		any a=new any(){
			
			
			//@SuppressWarnings("unused")
			public void out3(){
				System.out.println("This is inner out3");
			}
			@Override
			public void out2(){
				super.out2();
				out3();
				System.out.println("This is inner out2");
			}
		};
		a.out();
		a.out2();
		//a.out3();
	}
	
}
/*
 * anonymous class's method cannot be used by outer reference directly
 * for example, in any class, there is only out2() and out() without out3()
 * so, a only can call out(), and override out2();
 * it cannot call out3()
 * 
 *  thinking interface, it also call the override method
 */
