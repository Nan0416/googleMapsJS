package inher;

public class jj {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		p3 p=new p3();
	}

}
class p2{
	public p2(){
		System.out.println(12);
	}
}
class p3 extends p2{
	
}
