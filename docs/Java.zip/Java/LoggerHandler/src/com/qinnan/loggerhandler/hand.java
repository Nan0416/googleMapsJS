package com.qinnan.loggerhandler;

import java.io.IOException;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

public class hand {
	public static void main(String [] args){
		Logger logger=Logger.getLogger("com.qinnan.some");
		logger.setLevel(Level.FINE);
		//logger.setUseParentHandlers(false);
		FileHandler handler;
		try {
			//handler = new FileHandler();
			//default in the home dir
			handler=new FileHandler("%h/filehandlerlog%gth.log",true);
			//true append;
			//%h home
			// /filehandlerlog%gth.log file name
			//%g is the number to discriminate the different log file
			logger.addHandler(handler);
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ConsoleHandler h=new ConsoleHandler();
		
		logger.addHandler(h);
		//double msg
		logger.info("ms");
		logger.fine("fine");
		
	}
}	
