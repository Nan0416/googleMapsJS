package com.qinnan.inher1;

public class superclass {
	private String name;
	protected final short age;
	public superclass(){
		name = "";
		age = 0;
				
	}
	public superclass(String name, int age){
		this.name = name;
		this.age = (short)age;
	}
	public final String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public short getAge() {
		return age;
	}
	public void setAge(short age) {
		//this.age = age;
	}
	public void whatis(){
		System.out.println("This is super!");
	}
	public boolean equals(Object sup){
		if (name.equals(((superclass) sup).getName())){
			return true;
		}else{
			return false;
		}
		
	}
	public String toString(){
		return name + " " + age;
	}
	public void setName(String... name){
		for(String i: name){
			this.name += i;
		}
	}
	private void superpri(){
		System.out.println("this is private");
	}
	protected void subpub(){
		System.out.println("This is protected super.");
	}
}
