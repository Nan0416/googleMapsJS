package com.qinnan.inher1;

public class Driver {
	public static void main(String [] args){
		subclass1 sub1 = new subclass1();
		subclass1 sub2 = new subclass1("Charles", 66, 15450.00);
		System.out.println(sub2.getName() + " " +sub2.getAge() + " " + sub2.getSalary());
		sub2.agediv4();
		sub2.time2name();
		System.out.println(sub2.getName() + " " +sub2.getAge() + " " + sub2.getSalary() + " " + sub2.getsuperAge());
		superclass sup = new superclass();
		subclass1 sub = new subclass1();
		superclass [] classArray = new superclass[]{ sup, sub};
		classArray[0].whatis();
		classArray[1].whatis();
		superclass super1 = (superclass) sub;
		super1.whatis();
		subclass1 sub3 = (subclass1) super1;
		sub3.whatis();
		try{
			subclass1 sub4 = (subclass1) sup;
		}catch(ClassCastException e){
			System.out.println(e);
			
		}
		if(super1 instanceof subclass1){
			System.out.println("Cool!");
		}
		System.out.println(sub2);
		superclass sup2 = new superclass();
		sup2.setName("qin", " nan");
		System.out.println(sup2);
		sub2.subpub();
	}
}
