package com.qinnan.inher1;

public class subclass1 extends superclass{
	private double salary;
	private int age;
	public subclass1(){
		super();
		this.salary = 0;
		
	}
	public subclass1(String name, int age, double salary){
		super(name, age);
		this.salary = salary;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public void time2name(){
		//name +=name;
		setName(getName() + getName());
		
	}
	public void agediv4(){
		age /=4;
	}
	public short getAge(){
		return (short)(age-1);
	}
	public short getsuperAge(){
		return super.age;
	}
//	public short getAge(){
//		return (double)age;
//	}
//	public int getSalary(){
//		return (int)salary;
//	}
	public void whatis(){
		System.out.println("This is a sub...");
	}

//	public String getName(){
//		return "name";
//	}
//	
	public int setAge(boolean age){
		return 11;
	}
	public String toString(){
		return super.getName() + " " + age + " " + salary; 
	}
	public void superpri(){
		//super.superpri()
		//since it is private super
	}
	public void subpub(){
		super.subpub();
	}
}
