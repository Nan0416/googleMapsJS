package com.qinnan.inher2;

import com.qinnan.inher1.superclass;

public class subclass1 extends superclass{
	private double salary;
	public subclass1(){
		super();
		this.salary = 0;
		
	}
	public subclass1(String name, int age, double salary){
		super(name, age);
		this.salary = salary;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	

}
