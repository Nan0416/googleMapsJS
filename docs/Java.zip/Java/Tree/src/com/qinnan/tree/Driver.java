package com.qinnan.tree;

public class Driver {
	public static void main(String [] args){
		Tree<Key, String> tree = new Tree<>();
		tree.add_and_update(new Key("M"), "This is the root node.");
		tree.add_and_update(new Key("F"), "The first left node");
		tree.add_and_update(new Key("R"), "The first right node");
		tree.add_and_update(new Key("B"), "Banana.");
		tree.add_and_update(new Key("A"), "iPhone.");
		tree.add_and_update(new Key("C"), "You get a C.");
		tree.preorder_traversal();
		tree.queue_breadth_first_traversal(new operation2());
		System.out.println("Size: " + tree.count_node() + " Height: " + tree.height());
		tree.delete(new Key("B"));
		System.out.println("Size: " + tree.count_node() + " Height: " + tree.height());
		
		
		
		
	}
	
	
}
class Key implements Compare {
	private String value;
	public Key(String value){
		this.value = value;
	}
	@Override
	public int my_compare(Compare obj) {
		int temp = value.compareTo(((Key)obj).value);
		
		if (temp < 0){
			return -1;
		}else if (temp == 0){
			return 0;
		}else{
			return 1;
		}
	}
	public String toString(){
		return value;
	}
		
}

class operation1 implements Manipulate<String> {
	@Override
	public void dosomething(String obj) {
		System.out.println(obj);
	}
}
class operation2 implements Manipulate<String> {
	@Override
	public void dosomething(String obj) {
		System.out.println("Operate with 2: " + obj);
	}
}