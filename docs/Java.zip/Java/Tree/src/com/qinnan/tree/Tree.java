package com.qinnan.tree;

public class Tree <Key extends Compare, Value> {
	private class Node {
		private Key key;
		private Value data;
		private Node left;
		private Node right;
		private Node (Key key, Value data, Node left, Node right){
			this.key = key;
			this.data = data;
			this.left = left;
			this.right = right;
		}
	}
	private Node root;
	public Tree(){
		root = null;
	}
	public void add_and_update(Key key, Value data) {
		if(root == null){
			root = new Node(key, data, null, null);
			return; 
		}else{
			Node temp = root;
			while(true){
				if(key.my_compare(temp.key) == 1){ // true right
					if(temp.right == null){
						temp.right = new Node(key, data, null, null);
						return;
					}else{
						temp = temp.right;
					}
				}else if(key.my_compare(temp.key) == -1){
					if(temp.left == null){
						//System.out.println("left" + key);
						temp.left = new Node(key, data, null, null);
						return;
					}else{
						temp = temp.left;
					}
				}else{
					temp.data = data;
					return;
				}
			}
			
		}
	}
	private void preorder_traversal(Node root){
		if(root == null){
			return;
		}else{
			System.out.println("Key: " + root.key.toString() + " Value: " + root.data.toString());
			preorder_traversal(root.left);
			preorder_traversal(root.right);
		}
	}
	public void preorder_traversal(){
		preorder_traversal(root);
	}
	
	private void inorder_traversal(Node root){
		if(root == null){
			return;
		}else{
			preorder_traversal(root.left);
			System.out.println("Key: " + root.key.toString() + " Value: " + root.data.toString());
			preorder_traversal(root.right);
		}
	}
	public void inorder_traversal(){
		inorder_traversal(root);
	}
	
	private void postorder_traversal(Node root){
		if(root == null){
			return;
		}else{
			preorder_traversal(root.left);
			preorder_traversal(root.right);
			System.out.println("Key: " + root.key.toString() + " Value: " + root.data.toString());
		}
	}
	public void postorder_traversal(){
		postorder_traversal(root);
	}
	
	private void queue_breadth_first_traversal(Node root, Manipulate<Value> obj){
		if(root == null){
			return;
		}else{
			Queue<Node> q = new Queue<>(); 
			// Queue<Value> q = new Queue<>();
			q.enqueue(root);
			//q.enqueue(root.data);
			while(!q.isEmpty()){
				Node n = q.dequeue();
				//
				obj.dosomething(n.data);
				if(n.left != null){
					q.enqueue(n.left);
				}
				if(n.right != null){
					q.enqueue(n.right);
				}
			}
		}
	}
	public void queue_breadth_first_traversal(Manipulate<Value> obj){
		// here cannot use Node, since node is only visible inside class
		// cannot be seen outside this class.
		queue_breadth_first_traversal(root, obj);
	}
	public Value search(Key key){
		if(root == null){
			throw new IllegalStateException("Tree is empty!");
		}else{
			Node temp = root;
			while(temp != null){
				int comp = temp.key.my_compare(key);
				if(comp == 0){
					return temp.data;
				}else if(comp == -1){
					temp = temp.left;
				}else{
					temp = temp.right;
				}
			}
		throw new IllegalStateException("404!");
		}	
	}
	
	private int count_node(Node root){
		if(root == null){
			return 0;
		}else{
			return 1 + count_node(root.left) + count_node(root.right);
		}
	}
	public int count_node(){
		return count_node(root);
	}
	
	private int height(Node root){
		if(root == null){
			return 0;
		}else{
			int left = height(root.left);
			int right = height(root.right);
			int temp = (left > right)? left:right;
			return temp + 1;
		}
	}
	public int height(){
		return height(root);
	}
	
	// deletion with two temp node above and below, (right & left)
	// when implement need to refer the whole tree, like traversal, height, and count_node using recursion
	// otherwise, with loop.
	// the recursive function need a wrapper function to encapsulate
	
	
	public void delete(Key key){
		Node above = new Node(null,null,root,null); //as the head
		Node below = root;
		while(true){
			if(below == null){
				throw new IllegalArgumentException("No such key.");
			}else{
				int temp = key.my_compare(below.key);
				if(temp < 0){
					above = below;
					below = below.left;
				}else if(temp > 0){
					above = below;
					below = below.right;
				}else{ // found, deletion
					if(below.left == null){ // one part is null
						if(above.left == below){ // here using pointer comparison
							above.left = below.right;
						}else{
							above.right = below.right;
						}
					}else if(below.right == null){
						if(above.left == below){ // here using pointer comparison
							above.left = below.left;
						}else{
							above.right = below.left;
						}
					}else{// complicated case, replace the node with maximum node of the left subtree 
						Node goner = below;
						Node new_above = goner;
						Node new_below = goner.left;
						
						while(new_below.right != null){
							new_above = new_below;
							new_below = new_below.right;
						}// then this node must not have the right node
						// first deal with the (deletion) maximum node of left subtree
						if(new_above.left == new_below){
							// in case of the left subtree only has a root.
							new_above.left = new_below.left;
						}else{
							new_above.right = new_below.left;
						}
						goner.key = new_below.key;
						goner.data = new_below.data;
						
						
					}
					break;
				}
			}
		}
	}
	
}

interface Compare {
	public int my_compare(Compare obj);
	
}

interface Manipulate<Base>{
	public void dosomething(Base obj);
}
