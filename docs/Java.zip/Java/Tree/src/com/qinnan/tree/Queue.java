package com.qinnan.tree;

public class Queue<Base> {
	private class Node{
		private Base object;
		private Node next;
		private Node(Base object, Node next){
			this.object = object;
			this.next = next;
		}
	}
	private Node front;
	private Node rear;
	public Queue(){
		front = null;
		rear = null;
	}
	public boolean isEmpty(){
		return front == null;
	}
	public void enqueue(Base object){
		if(isEmpty()){
			front = rear = new Node(object, null);
		}else{
			rear.next = new Node(object, null);
			rear = rear.next;
		}
	}
	public Base dequeue(){
		if(isEmpty()){
			throw new IllegalStateException("MTQ");
		}else{
			Base temp = front.object;
			front = front.next;
			return temp;
			
		}
	}
}
