package com.qinnan.string;

public class drive {
	public static void main(String [] args){
		int [] arg = new int[]{1,1,3,4,5};
		int temp = 0;
		for(int i:arg){
			temp =0;
			for(int j:arg){
				if(i==j){
					temp++;
				}
				
			}
			if(temp!=1){
				System.out.println("as");
			}
			
		}
		System.out.println("ss");
		
	}
}
