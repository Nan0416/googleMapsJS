package com.qinnan.generic;

public class ImplementsInterface implements Add<String/* a concrete class*/> {
	String b="qin";
	public void add(String /*here must be String, same as the add<T>*/ a){
		b=b+a;
	}
}
