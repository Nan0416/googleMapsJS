package com.qinnan.generic;

public class GenericClassWithBound<U,T extends Add<U/*here must be a concrete type*/>> {
	public T add(T a,U b){
		a.add(b);
		return a;
	}
}
