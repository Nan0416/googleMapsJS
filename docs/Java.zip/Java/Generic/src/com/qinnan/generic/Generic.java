package com.qinnan.generic;

public class Generic<T>{
	private T a;
	public Generic(T a){
		this.a=a;
	}
	public void print(){
		System.out.println(a.toString());
	}
	public T geta(){
		return a;
	}
	public void replace(T b){
		a=b;
	}
//	public void add(T b){
//		a=a+b;
//	}

}
