package com.qinnan.generic;

public class Drive  {
	public static void main(String [] args){
		Generic<String> g=new Generic<>("qinnan");
		g.print();
		String h1=g.geta();
//		Generic<int> g2=new Generic<>(2);
//		g2.print();
		Generic<Integer> g3=new Generic<>(2);
		g3.print();
		
		GenericMethodWithOrdinaryClass g4=new GenericMethodWithOrdinaryClass();
		String h2=g4.getThird("qinnan","is","a","good","man");
		System.out.println(h2);
		
		Integer h3=g4.<Integer>getThird(1,2,3);
		System.out.println(h3);
		Object h4=g4.getThird(2.3,234f,3);
		System.out.println(h4+" "+h4.getClass().getName());
		
		System.out.println(GenericMethodWithOrdinaryClass.<String>getmiddle("qinnan","is","a","good","man"));
		
		GenericClassWithBound<String,ImplementsInterface> g2= new GenericClassWithBound<>();
		//
		ImplementsInterface g6=new ImplementsInterface();
		g2.add(g6,"nan");
		System.out.println(g6.b);
		if(g2 instanceof GenericClassWithBound){
			System.out.println("Yes");
		}
		//only can check the raw type
		Class<String> c2=String.class;
		//<?>
		try {
			Y i=Y.class.newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}

class Y{
	private Y(){}
	public void println(){
		System.out.println("Qinnan");
	}
}
