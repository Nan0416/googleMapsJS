package com.qinnan.generic;

public class GenericMethodWithOrdinaryClass {
//	public static <T> T get(){
//		T a=new T();
//		cause T may not have the default constructor
//		return a;
//	}
	public static <T> T getmiddle(T... a){
		return a[a.length/2];
		//a is a []
		//so it has length parameter
	}
	public <r> r getThird(r... a){
		return a[a.length/3];
	}
	
}
