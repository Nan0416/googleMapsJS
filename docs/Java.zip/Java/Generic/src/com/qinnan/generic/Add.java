package com.qinnan.generic;

public interface Add<T>{
	public abstract void add(T b);
}
