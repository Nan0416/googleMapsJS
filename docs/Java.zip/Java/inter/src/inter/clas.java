package inter;

import java.util.logging.Logger;

public class clas {
	public void ma(){
		Logger.getGlobal().fine(this.toString());
	}
	public static void mas(){
		//Logger.getGlobal().fine(this.toString());
	}
	public static void main(String [] args){
		//clas n=new clas();
		//n.ma();
		String [] ar=new String[]{"",""};
		
		clas.main(ar);
	}
		
	
}

