package com.qinnan.array;

import java.util.Arrays;

public class array {
	public static void main(String [] args){
		int [] num = new int [10];
		for (int i = 0; i< num.length-2; i++){
			num[i] = i;
		}
		//num.length= 100; lenght is final type
		String [] words = new String[10];
		for (int i = 0;i < words.length-1; i++){
			words[i]= new String("qinnan");
		}
		System.out.println(words.toString() + "\n" + num.toString());
		for (int i:num){
			System.out.print(i+ " ");
		}
		System.out.println();
		for (String i:words){
			System.out.print(i+ " ");
		}
		String [] newwords = new String [] {new String("nan"), new String("hello")};
		// first new to create the array instance, in the curly brace , new to create String
		for (String i:newwords){
			System.out.print(i+ " ");
		}
		int [] prime = new int[]{1,2,4,5};
		// when instantiate like this, you are forbidden to provide the number in the square brace
		for (int i:prime){
			System.out.print(i+ " ");
		}
		String [] copy = Arrays.copyOf(newwords, 10);
		for (String i : copy){
			System.out.print(i+ " ");
		}
		
		String [][] two_dimension = new String [3][4];
		two_dimension[2][3] = new String("qinanna");
		System.out.print("\n"+two_dimension[2][3]);
		
		
	}
}
