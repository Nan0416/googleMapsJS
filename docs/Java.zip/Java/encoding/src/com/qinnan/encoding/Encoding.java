package com.qinnan.encoding;

import java.io.UnsupportedEncodingException;

public class Encoding {
	public static void main(String [] args) throws UnsupportedEncodingException{
		//enter utf-8;
		String hu="你好ABC";
		byte [] hu2=hu.getBytes("utf-16be");//default get utf-8;
		for(byte i:hu2){
			System.out.print(Integer.toHexString(i&0xff)+" ");
		}
		System.out.println();
		byte [] hu3;
		byte temp;
		//text 00 ff 
		hu3=new byte[2];
		hu3[0]=(byte)0xff;
		hu3[1]=(byte)0x00;
		String hu4=new String(hu3,"utf-16be");
		System.out.println(hu4);
		// 00 ff doesn't coding
		byte []hu5=new byte[hu2.length];
		for(int i=0;i<hu2.length;i++){
			hu5[i]=(byte)((int)hu2[i]+1);
			//coding algorithm
		}
		for(byte i:hu5){
			System.out.print(Integer.toHexString(i&0xff)+" ");
		}
		System.out.println();
		String hu6=new String(hu5,"utf-16be");
		System.out.println(hu6);
		
	}
}
