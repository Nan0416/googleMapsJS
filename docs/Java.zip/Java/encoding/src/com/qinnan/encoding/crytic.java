package com.qinnan.encoding;

import java.io.UnsupportedEncodingException;

public class crytic {
	private byte [] B;
	private String S;
	private long num=0;
	public crytic(){
		num = 0;
	}
	public void encoding(String input) throws UnsupportedEncodingException{
		B = input.getBytes("utf-16be");
		Num();
	}
	private void Num(){
		for(int i =0; i< B.length; i++){
			num += B[i]*Math.pow(255, i);
		}
	}
	private void DeNum(){
		long temp ;
		long temp2 ;
		String len = "";
		do{
			temp = num % 255;
			temp2 = num /255;
			len += temp + " "; 
		}while(temp2>0);
		int space = 0;
		for(int i=0; i< len.length();i++){
			if(len.substring(i, i+1).equals(" ")){
				space ++;
			}
		}
		Byte [] newB = new Byte[space];
		
		
	}

}
