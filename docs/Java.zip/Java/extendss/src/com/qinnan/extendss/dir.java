package com.qinnan.extendss;

public class dir {
	public static void main(String [] args){
		superr i=new Chidl();
		i.out();
		//i.out2();
		((Chidl)i).out2();
		
	}
}
