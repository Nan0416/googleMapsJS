package com.qinnan.extendss;

public class superr {
	public void out(){
		System.out.println("Out");
	}
}
