package com.qinnan.extendss;

public class Chidl extends superr {
	public void out2(){
		System.out.println("out2");
	}
}
