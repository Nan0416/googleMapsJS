package com.qinnan.exeption;

public class Drive {
	public static void main(String [] args){
		Error e = new Error();
		try{
			e.uncatch();
		}catch(IllegalArgumentException e2){
			System.out.println("catch IllegalArgumentException.");
		}
		try{
			e.catchthrowsnew();
		}catch(IllegalAccessException e3){
			System.out.println("catch + " + e3.toString());
		}
		finally{
			System.out.println("finally e3");
		}
		try{
			System.out.println("finally a");
		}catch(Exception e5){
			System.out.println("finally b");
		}finally{
			System.out.println("finally c");
		}
		try{
			e.uncatchthrow();
		}catch(Exception e6){
			System.out.println("finally e3");
		}
		// exception
		// with catch, catched, uncatched
		// without catch
		// finally must implement
		// 
		
		try{
			System.out.println("finally ee3");
		}finally{
			System.out.println("finally dd");
		}
		try{
			e.exception();
		}finally{
			System.out.println("finally cd");
		}
		
		
	}
}

class Error{
	public void exception() throws IllegalArgumentException{
		throw new IllegalArgumentException();
	}
	public void uncatch(){ 
		// this function is equivalent to handle no exception.
		// so here, although not follow throws IllegalArgumentException, it also will throws
		try{
			exception();
		}catch(IllegalStateException e){
			System.out.println("catch IllegalStateException.");
		}
	}
	public void catched(){
		try{
			exception();
		}catch(IllegalArgumentException e){
			System.out.println("catch IllegalArgumentException.");
		}
	}
	public void uncatchthrow() throws IllegalArgumentException{
		try{
			exception();
		}catch(IllegalStateException e){
			System.out.println("catch IllegalStateException.");
		}
		finally{
			System.out.println("finally inner uncatchthrow");
			
		}// finally must implements. no matter what happen
		
	}
	public void catchthrowsnew() throws IllegalAccessException{
		try{
			exception();
		}catch(IllegalArgumentException e){
			System.out.println("catch IllegalStateException.");
			throw new IllegalAccessException();
		}
		finally{
			System.out.println("finally inner");
		}
	}
	
}