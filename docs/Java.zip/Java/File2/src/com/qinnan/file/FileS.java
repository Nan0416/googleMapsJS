package com.qinnan.file;

import java.io.File;
import java.io.IOException;

public class FileS {
	public static void main(String [] args) throws IOException{
		File file_in2=new File("/Users/hatakusunoki/jj.cpp");
		File file_in=new File("/as.ss");
		System.out.println(file_in.exists());
		if(file_in.exists()){
			try{
				file_in.delete();
			}catch(SecurityException e){
				e.printStackTrace();
			}
		}
		else{
			file_in.createNewFile();
		}
	}
}
