package com.qinnan.add;

import java.net.InetAddress;
import java.io.IOException;

public class networkAddress {
	public static void main(String [] args) throws IOException{
		InetAddress [] hostAll=InetAddress.getAllByName("www.umn.edu");
		for(InetAddress temp:hostAll){
			System.out.println(temp.getHostAddress()+"\n"+temp.getHostName());
			System.out.println(temp.getCanonicalHostName());
		}
		byte [] addr=new byte[]{(byte) 192,(byte)168,(byte)56,(byte)1};
		InetAddress server=InetAddress.getByAddress(addr);
		System.out.println(server.isReachable(10000));
		
	}

}
