package com.qinnan.arraylist;

import java.util.ArrayList;
import java.util.Iterator;

public class drive {
	public static void main(String [] args){
		ArrayList list = new ArrayList(20);
		list.add("Element 1");
		list.add(1,"Element 3");
		String hu = (String) list.get(1);
		StringBuilder hu2 =new StringBuilder("Element 4");
		list.add(hu2);
		System.out.println(list.contains(new StringBuilder("Element 4")) +" "+ list.contains(hu2));
		
//		for(char i : "qinann"){
//			
//		}
		//String does implement iterator protocol
		for(Object i:list){
			String ji =i.toString();
			System.out.println(ji);
		}
		Object [] obj = list.toArray();
		Iterator<Object> ji = list.iterator();
		//since there is a StringBuilder
//		for(Object i:ji){
//			System.out.println(i.toString());
//			
//		}
		//java cannot iterate iterator directly
		
		//String [] obj2 = (String [])obj;
		// cannot directly cast array
		String [] obj2 = new String [obj.length];
		for(int i= 0;i<obj.length;i++){
			obj2[i] = obj[i].toString();
		}

		for(String i:obj2){
			
			System.out.println(i);
		}
	}
}
 