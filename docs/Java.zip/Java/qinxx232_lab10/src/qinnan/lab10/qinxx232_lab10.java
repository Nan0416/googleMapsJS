package qinnan.lab10;

import java.lang.IllegalStateException;

public class qinxx232_lab10{
	public static void main(String [] args){
		Deque<String> myDeque = new Deque<String>();
		myDeque.enqueueFront("B");
		myDeque.enqueueFront("A");
		myDeque.enqueueRear("C");
		myDeque.enqueueRear("D");
		myDeque.enqueueRear("E");
		for(int i = 0; i < 5; i++){
			System.out.println(myDeque.dequeueFront());
		}
		try{
			myDeque.dequeueRear();
		}catch(IllegalStateException e){
			System.out.println(e);
		}
		
//		A
//		B
//		C
//		D
//		E
//		java.lang.IllegalStateException
		
		myDeque.enqueueRear("C");
		myDeque.enqueueRear("D");
		myDeque.enqueueRear("E");
		myDeque.enqueueFront("B");
		myDeque.enqueueFront("A");
		for(int i = 0; i < 5; i++){
			System.out.println(myDeque.dequeueRear());
		}
		try{
			myDeque.dequeueFront();
		}catch(IllegalStateException e){
			System.out.println(e);
		}
		
//		E
//		D
//		C
//		B
//		A
//		java.lang.IllegalStateException
		
	}
}

class Deque<Base>{
	private class Node{
		private Base object;
		private Node left;
		private Node right;
		
		private Node (Base object, Node left, Node right){
			this.object = object;
			this.left = left;
			this.right = right;
		}
	}
	private Node head;
	
	public Deque(){
		head = new Node(null, null, null);
		head.left = head;
		head.right = head;
	}
	
	public void enqueueFront(Base object){
		Node temp = new Node(object, head, head.right);
		head.right.left = temp;
		head.right = temp;
	}
	
	public void enqueueRear(Base object){
		Node temp = new Node(object, head.left, head);
		head.left.right = temp;
		head.left = temp;
	}
	
	public Base dequeueFront(){
		if(isEmpty()){
			throw new IllegalStateException();
		}
		Node temp = head.right;
		head.right = temp.right;
		temp.right.left = head;
		return temp.object;
	}
	
	public Base dequeueRear(){
		if(isEmpty()){
			throw new IllegalStateException();
		}
		Node temp = head.left;
		head.left = temp.left;
		temp.left.right = head;
		return temp.object;
	}
	
	public boolean isEmpty(){
		return head.left == head;
	}
	
}
