package com.qinnan.stringpractice;

public class string {
	public static void main(String [] args){
		String ß = new String("This is a ß.");
		String 秦 = new String("This is a Chinese Character.");
		System.out.println(秦 + ß);
		中文 你好 =new 中文("你好");
		你好.设置("您好");
		System.out.println(你好.得到内容());
		String sub = "Hello, it is Nan.";
		String name = sub.substring(13, 16);
		// left inclusive, right exclusive
		String concat = sub + name;
		if (concat.equals(sub + name)){
			System.out.println(concat);
		}
		int len = concat.length();
		char second = concat.charAt(1);
		
			//char unexisted = concat.charAt(100);
			// error Exception
		System.out.println(len + " " + second  );
		int index = concat.offsetByCodePoints(1,1);
		int cp =concat.codePointAt(index);
		//return ascii value
		System.out.println(index + " " + cp);
		
		
	}
	

}
class 中文{
	// since unicode encoding. so it is happy to use other language to code 
	private int 数量;
	private String 内容;
	
	public 中文(String 初始值){
		内容 = 初始值;
	}
	public void 设置(String 内容){
		this.内容 = 内容;
	}
	public String 得到内容(){
		return 内容;
	}
}