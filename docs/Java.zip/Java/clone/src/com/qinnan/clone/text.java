package com.qinnan.clone;

public class text  {
	private StringBuilder content;
	public StringBuilder get(){
		return content;
	}
	public text clone() throws CloneNotSupportedException{
		//text temp = (text) super.clone();
		// this is not allow, even call the default clone() is appropriate 
		// you need to implement Cloneable method
		text temp = new text(content.toString());
		
		//StringBuilder nw = new StringBuilder(content.toString());
		//temp.content = nw;
		//you can directly access the private fields in its class;
		return temp;
	}
	public text(String temp){
		content = new StringBuilder(temp);
	}
}
