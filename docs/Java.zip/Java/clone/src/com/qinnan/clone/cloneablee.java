package com.qinnan.clone;

public class cloneablee implements Cloneable {
	private StringBuilder content;
	public StringBuilder get(){
		return content;
	}
	public cloneablee clone() throws CloneNotSupportedException{
		// the exception will work when class does not implement Cloneable interface
		return (cloneablee) super.clone();
		// super.clone just copy a reference , so it only works for primitive types
		
		
	}
	public cloneablee(String temp){
		content = new StringBuilder(temp);
	}
}
