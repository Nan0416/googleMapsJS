package com.qinnan.clone;

public class drive {
	public static void main(String [] args) throws CloneNotSupportedException{
		text tx1 = new text("qinnan");
		text tx2 = tx1;
		if(tx2.get() == tx1.get()){
			System.out.println("= assignment only copies reference.");
		}else{
			System.out.println("Success.");
		}
		text tx3 = tx1.clone();
		if(tx3.get() == tx1.get()){
			System.out.println("= assignment only copies reference.");
		}else{
			System.out.println("Success.");
		}
		cloneablee cl1 = new cloneablee("qinnan");
		cloneablee cl2 = cl1;
		if(cl2.get() == cl1.get()){
			System.out.println("= assignment only copies reference.");
		}else{
			System.out.println("Success.");
		}
		cloneablee cl3 = cl1.clone();
		if(cl3.get() == cl1.get()){
			System.out.println("= assignment only copies reference.");
		}else{
			System.out.println("Success.");
		}
	}

}
