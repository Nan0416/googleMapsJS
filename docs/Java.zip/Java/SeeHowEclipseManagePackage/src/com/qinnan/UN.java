package com.qinnan;

public class UN {
	public void out(){
		System.out.println("This is UN");
		
	}

}
