import com.qinnan.UN;

public class Drive {
	public static void main(String [] args){
		UN u=new UN();
		u.out();
		
	}
}
