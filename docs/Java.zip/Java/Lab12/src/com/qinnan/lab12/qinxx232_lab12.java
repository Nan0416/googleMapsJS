package com.qinnan.lab12;

public class qinxx232_lab12 {
	 public static void main(String [] args)  
	  {  
	    PriorityQueue<String> queue = new PriorityQueue<String>();  
	    System.out.println(queue.isEmpty());  
	  
	    queue.enqueue("Fawlty", 7);  
	    queue.enqueue("Elizabeth", 0);  
	    queue.enqueue("Charles", 1); 
	    queue.enqueue("Mary", 3);
	    queue.enqueue("William", 4);
	    queue.enqueue("Turing", 7);  
	    while(true){
	    	try{
	    		System.out.println(queue.dequeue()); 
	    	}catch(IllegalStateException e){
	    		break;
	    	}
	    } 
	 
	    System.out.println(queue.isEmpty());  
//	    true
//	    Elizabeth
//	    Charles
//	    Mary
//	    William
//	    Fawlty
//	    Turing
//	    true
	  }  
}

class PriorityQueue<Base>  
{  
  private class Node  
  {  
    private Base object;  
    private int rank;  
    private Node left;  
    private Node right;  
  
    private Node(Base object, int rank)  
    {  
      this.object = object;  
      this.rank = rank;  
      left = null;  
      right = null;  
    }  
  }  
  private Node head;
  public PriorityQueue(){
	  head = new Node(null, -1);
  }
  
  public Base dequeue(){
	  if(isEmpty()){
		  throw new IllegalStateException();
	  }else{
		  Node above = head;
		  Node below = head.left;
		  if(below.right == null){
			  above.left = below.left;
			  return below.object;
		  }
		  while(below.right != null){
			  above = below;
			  below = below.right;
		  }
		  above.right = below.left;
		  return below.object;
	  }
  }
  public void enqueue(Base object, int rank){
	  if(rank < 0){
		  throw new IllegalArgumentException();
	  }else{
		  Node temp = head;
		  while (true){
			  if(rank >= temp.rank){
				  if (temp.left == null){
					  temp.left = new Node(object, rank);
					  return;
				  }else{
					  temp = temp.left;
				  }
			  }else{
				  if (temp.right == null){
					  temp.right = new Node(object, rank);
					  return;
				  }else{
					  temp = temp.right;
				  }
			  }
		  }
	  }
  }
  public boolean isEmpty(){
	  return (head.left == null);
  }
  
}
