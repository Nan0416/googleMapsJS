package com.qinnan;
public class Child extends Base{
    public void out(){
        System.out.println("This is Child class");
    }
    public void out2(){
        System.out.println("This is Child class out2");
    }
}