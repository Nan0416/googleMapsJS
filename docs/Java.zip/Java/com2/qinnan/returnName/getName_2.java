package com.qinnan.returnName;
public class getName_2 extends getName_{
    
}