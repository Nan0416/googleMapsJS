package com.qinnan.arbitrary;
public class Para2{
    public String toString(){
        return ("This is Para2");
    }
}