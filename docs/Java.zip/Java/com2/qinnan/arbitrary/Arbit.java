package com.qinnan.arbitrary;
public class Arbit{
    public void out2(Object... args){
        for(Object o: args){
            System.out.println(o.toString());
        }
    }
    public void out3(Object...args){
        for(Object o:args){
            
            Class i=o.getClass();
            String a=i.getName();
            if(a.equals("java.lang.String")){
                if(o.equals("\n")){
                    System.out.println();
                }
            }else{
                System.out.print(a);
            }
        }
    }
}