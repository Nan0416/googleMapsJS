package com.qinnan.arbitrary;
public class Para1{
    public String toString(){
        return "This is Para1";
    }
}