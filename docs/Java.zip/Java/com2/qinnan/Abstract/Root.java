package com.qinnan.Abstract;
public abstract class Root{
    protected abstract void no1();
    protected abstract void no2();
    public void concrete(){
        no1();
        no2();
    }

}