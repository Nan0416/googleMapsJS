package com.qinnan.Abstract;
public abstract class AbstractTest{// if a class contains one or more abstract class, the class must be declared as abstract
    private String name;
    public void setName(String name){
        this.name=name;
    }
    public String getName(){
        return name;
    }
    public String hello(){
        return "Base";
    }
    public abstract String outputDescription();
    //private abstract void test1();
    //abstract cannot be private, becasue it will be redefined
    protected abstract String test2();
    //public final abstract String test3();
    // abstract and final cannot be together;
    
    

}