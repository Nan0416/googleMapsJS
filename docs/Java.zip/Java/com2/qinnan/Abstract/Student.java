package com.qinnan.Abstract;
public class Student extends AbstractTest{
    public String outputDescription(){
        return "I am A student.";
    }
    public String outputDescription(String name){// it has nothing with The abstract method in super class
        return name;
    }
    /*private String test2(){
        return "Test2";
    }*/
    //cannot use the different modifer
    public String test2(){
        return "Student";
    }
    //low the right;
    public String hello(){
        return "Child";
    }
    

}