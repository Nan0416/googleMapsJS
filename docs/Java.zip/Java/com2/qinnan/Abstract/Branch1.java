package com.qinnan.Abstract;
public class Branch1 extends Root{
    protected void no1(){
        System.out.println("This is Branch 1's no 1");
        
    }
    protected void no2(){
        System.out.println("This is Branch 1's no 2");
    }
    
}