package com.qinnan.interfaceintro;
public class interimple implements inter<interimple>{
    public int compare(){
        System.out.println("interimple1");
        return 2;
    }
    //must implement all methods
    public void compare2(){
        System.out.println("Inter");
    }
    public void compare3(){
        
    }
    public String toString(){
        return "safe";
    }
    public void rrr(interimple x){
       System.out.println(x.toString());
    }
}