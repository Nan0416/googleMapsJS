package com.qinnan.interfaceintro;
public interface inter<T>{
    public int compare();
    public void compare2();
    public void rrr(T x);
    public static final int x=100;
    //public static int y;
}