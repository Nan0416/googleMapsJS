package com.qinnan;

public class Base{
    public void out(){
        System.out.println("This is Base class");
    }
}