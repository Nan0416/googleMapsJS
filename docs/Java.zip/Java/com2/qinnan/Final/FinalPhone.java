package com.qinnan.Final;
public class FinalPhone{
    private int number;
    private String carrier;
    private double balance;
    private final int No;
    private static int numberPhone=0;
    public FinalPhone(int number,String carrier,double balance){
        this.number=number;
        this.carrier=carrier;
        this.balance=balance;
        numberPhone++;
        No=numberPhone;
    }
    public FinalPhone(){
        this(0,"",0.0);//calling another constructor
    }
    public void output(){
        System.out.println("Number: "+number+"\nCarrier: "+carrier+"\nBalance: "+balance+"\nNo."+No+"\nnumberPhone"+numberPhone);
    }
    private void out(){
        System.out.println("You");
    }
    protected void test1(){
        System.out.println("This is FinalPhone");
    }
    
}