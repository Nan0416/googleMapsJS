/*
public class Inheritance extends FinalPhone{ // you cannot inherit A final class
    private String holderName;
    public void setHolderName(String holderName){
        this.holderName=holderName;
    }
    public void output(){
        System.out.println("Number: "+number+"\nCarrier: "+carrier+"\nBalance: "+balance+"\nNo."+No+"\nnumberPhone"+numberPhone); //cannot output private members;
        System.out.println("HolderName: "+holderName);
    }
}
*/
package com.qinnan.Final;
public class Inheritance extends FinalPhone{ // you cannot inherit A final class
    private String holderName;
    public void setHolderName(String holderName){
        this.holderName=holderName;
    }
    public void output(){
        super.output();
        System.out.println("HolderName: "+holderName);
    }
    //don't inherit super constructors
    public Inheritance(){
        super();//calling base constructor;
        holderName="";
    }
    public Inheritance(int number,String carrier,double balance,String holderName){
        super(number,carrier,balance);
        this.holderName=holderName;
    }
    public void out2(){
        System.out.println("we");
    }
    public void test1(){
        System.out.println("This is inheritance");
    }//here you only can change test1 from protected to public
    //but not public to protect or private.
    
}