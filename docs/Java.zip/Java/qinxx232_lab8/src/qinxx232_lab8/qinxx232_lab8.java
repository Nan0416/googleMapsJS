package qinxx232_lab8;
import java.lang.IllegalStateException;
public class qinxx232_lab8 {
	 public static void main(String[] args)  
	  {  
	    RunnyStack<String> s = new RunnyStack<String>();  
	  
	    s.push("A");  
	    System.out.println(s.peek() + " " + s.depth() + " " + s.runs());  //  A 1 1  
	  
	    s.push("B");  
	    System.out.println(s.peek() + " " + s.depth() + " " + s.runs());  //  B 2 2  
	  
	    s.push("B");  
	    System.out.println(s.peek() + " " + s.depth() + " " + s.runs());  //  B 3 2  
	    
	    s.push("A");
	    System.out.println(s.peek() + " " + s.depth() + " " + s.runs());  //  A 4 3  
	    
	    s.push("A");
	    System.out.println(s.peek() + " " + s.depth() + " " + s.runs());  //  A 5 3  
	    
	    s.pop();  
	    System.out.println(s.peek() + " " + s.depth() + " " + s.runs());  //  A 4 3  
	  
	    s.pop();  
	    System.out.println(s.peek() + " " + s.depth() + " " + s.runs());  //  B 3 2
	    
	    s.push("C");
	    System.out.println(s.peek() + " " + s.depth() + " " + s.runs());  //  C 4 3  
	  }  
}

class RunnyStack<Base>{
	private class Run{
		private Base object;
		private int length;
		private Run next;
		private Run(Base object, Run next){
			this.object = object;
			this.next = next;
			this.length = 1;
		}
	}
	private Run top;
	private int total_length;
	private int runs;
	public RunnyStack(){
		top = null;
		total_length = 0;
		runs = 0;
	}
	public int depth(){
		return total_length;
	}
	public boolean isEmpty(){
		return top == null;
	}
	public Base peek(){
		if(isEmpty()){
			throw new IllegalStateException("Stack is empty");
		}else{
			return top.object;
		}
	}
	public void pop(){
		if(isEmpty()){
			throw new IllegalStateException("Stack is empty");
		}else{
			if(top.length == 1){
				top = top.next;
				runs --;
				total_length --;
			}else{
				top.length --;
				total_length --;
			}
		}
	}
	private boolean isEqual(Base obj1, Base obj2){
		if (obj1 == null){
			return obj2 == null;
		}else{
			return obj1.equals(obj2);
		}
	}
	public void push(Base object){
		if(isEmpty()){
			top = new Run(object,null);
			total_length ++;
			runs ++;
		}else{
			if(isEqual(top.object,object)){
				top.length ++;
				total_length ++;
			}else{
				top = new Run(object,top);
				runs ++;
				total_length ++;
			}
		}
		
	}
	public int runs(){
		return runs;
	}
	
}