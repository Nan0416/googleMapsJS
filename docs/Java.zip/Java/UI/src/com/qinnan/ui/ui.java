package com.qinnan.ui;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;

public class ui {
	public static void main(String [] args){
		EventQueue.invokeLater(new Runnable(){
			public void run(){
				JFrame window=new JFrame("NAN QIN");
				window.setSize(300, 420);
				window.setLocation(300,420);
				window.setLocationByPlatform(true);
				//window.setBounds(10,10,300,420);
				//from Window class, it also can set the size of windows
				window.setBackground(Color.CYAN);
				//window.setOpacity(0.5f);
				window.setVisible(true);
				window.setAlwaysOnTop(true);
				window.setResizable(true);
		
				//you cannot resize it smoothly, since this thread is sleeping;
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				window.setResizable(false);
				window.setTitle("Nan");
				
				
				try{
					window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				}catch(SecurityException e){
					e.printStackTrace();
				}
			}
		});
		System.out.println("Just something");
		/*EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				SimpleFrame frame = new SimpleFrame();
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});*/
	}
}
		
class SimpleFrame extends JFrame{
	private static final int DEFAULT_WIDTH = 300;
	private static final int DEFAULT_HEIGHT = 200;
	public SimpleFrame()
	{
		setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
	}
}
