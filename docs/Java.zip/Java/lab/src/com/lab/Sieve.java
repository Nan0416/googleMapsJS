package com.lab;
import java.lang.IllegalArgumentException;
public class qinxx232{
	public static void main(String [] args){
		Sieve sieve = new Sieve(100);  
	    sieve.findPrimes();  
	    System.out.println(sieve);  
	}
}



class Sieve {
	private boolean [] numbers;
	public Sieve(int max){
		if(max < 0){
			throw new IllegalArgumentException();
		}else{
			numbers = new boolean [max];
			for(int i = 0;i < max; i++){
				if(i < 2){
					numbers[i] = true;
				}else{
					numbers[i] = false;
				}
			}
			
		}
	}
	public void findPrimes(){
		for(int i = 2; i< numbers.length; i++){
			if(numbers[i]){
				for(int j = i + i;j<numbers.length;j = j+i){
					numbers[j] = false;
				}
			}
		}
	}
	public String toString(){
		String rs = "";
		for(int i = 2; i < numbers.length; i++){
			if(numbers[i]){
				rs += i+" ";
			}
		}
		return rs;
	}
	

}
