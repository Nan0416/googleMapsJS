package com.qinnan.rand;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;
public class randomaccess {
	public static void main(String [] args) throws IOException{
		File file=new File("Hello.dat");
		if(!file.exists()){
			file.createNewFile();
		}
		RandomAccessFile raf=new RandomAccessFile(file,"rw");
		System.out.println(file.getAbsolutePath());
		System.out.println(raf.getFilePointer());
		int hu=12233;
		raf.write((byte)(hu>>>(8*3)));//>> and >>> 1 to fulfill, and 0 to fulfill
		raf.write(hu>>>(8*2));//actually you don't need to switch it into byte, this method noly write 
		//one byte
		raf.write(hu>>>8);
		raf.write(hu);
		raf.writeInt(1242);
		//automatically like the above algorithm
		
		
		System.out.println(raf.getFilePointer());
		String hu2="秦楠";//
		byte [] b=hu2.getBytes("utf-8");
		for(byte i:b){
			raf.write(i);
		}
		System.out.println(raf.getFilePointer());
		byte [] b2="秦楠".getBytes("utf-16be");
		raf.write(b2);
		//it can write a byte array
		System.out.println(raf.getFilePointer());
		//ready to read
		raf.seek(0);
		byte [] hu3=new byte[(int)raf.length()];
		raf.read(hu3);
		//once write all
		System.out.println(raf.getFilePointer());
		System.out.println(Arrays.toString(hu3));
		int hu5=0;
		for(int i=0;i<4;i++){
			int temp=hu3[i];
			//fulfill with 1 when hu3[i] is less than 0
			temp=temp&0x0000ff;
			
			hu5=(temp<<8*(3-i))|hu5;
			
			
		}
		System.out.println(hu5);
		byte [] name=new byte[6];
		for(int i=0;i<6;i++){
			name[i]=hu3[i+8];
		}
		String hu6=new String(name,"utf-8");
		System.out.println(hu6);
		raf.close();
	}

}
