import java.util.*;
import java.lang.*;
public class hashCodeJava{
    public static void main(String [] args){
        String u;
        hashCodeJava u11=new hashCodeJava();
        u="Hello";
        System.out.println(u.hashCode());
        System.out.println(Objects.hashCode("hello"));
        System.out.println(System.out);
        System.out.println(u11);
    }

}