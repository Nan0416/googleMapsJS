package com.qinnan.project3;

import java.util.Random;


public class qinxx232_project3 {
	public static void main(String [] args){
		 SBST<Integer> sbst = new SBST<Integer>(30); 
		 System.out.println(sbst.height());
		 for (int index = 0; index < reserved.length; index += 1)  
		 {  
			 sbst.put(reserved[index], index);  
		 }  
		 System.out.println(sbst.height());  
		 for (int index = 0; index < reserved.length; index += 1)  
		 {  
			 System.out.format("%02d %s", sbst.get(reserved[index]), reserved[index]);  
			 System.out.println();  
		 }  
	    
	}
	private final static String[] reserved =  
		   { "abstract",     "assert",    "boolean",     "break",  
		     "byte",         "case",      "catch",       "char",  
		     "class",        "const",     "continue",    "default",  
		     "do",           "double",    "else",        "extends",  
		     "final",        "finally",   "float",       "for",  
		     "goto",         "if",        "implements",  "import",  
		     "instanceof",   "int",       "interface",   "long",  
		     "native",       "new",       "package",     "private",  
		     "protected",    "public",    "return",      "short",  
		     "static",       "super",     "switch",      "synchronized",  
		     "this",         "throw",     "throws",      "transient",  
		     "try",          "void",      "volatile",    "while" };  
}
class SBST<Value>{
	private class Node{
		private String key;
		private Value value;
		private Node left;
		private Node right;
		private Node(String key, Value value, Node left, Node right){
			this.key = key;
			this.value = value;
			this.left = left;
			this.right = right;
		}
	}
	private String [] keys;
	private Value [] values;
	private int count;
	private Random r;
	private Node root;
	@SuppressWarnings("unchecked")
	public SBST(int size){
		if(size < 0){
			throw new IllegalArgumentException();
		}else{
			count = 0;
			root = null;
			r = new Random();
			keys = new String[size];
			
			values = (Value []) new Object[size];
		}	
	}
	
	private void flush(){
		int j = 0;
		String temp = null;
		Value temp2 = null;
		for(int i = 0; i < count-1; i++){
			j = r.nextInt(count - i);
			temp = keys[i];
			temp2 = values[i];
			keys[i] = keys[i + j];
			values[i] = values [i + j];
			keys[i + j] = temp;
			values[i + j] = temp2;
		}
		for(int i = 0; i < count; i++){
			putting(keys[i], values[i]);
		}
		count = 0;
	}
	public Value get(String key){
		if(count != 0){
			flush();
		}
		if(root == null){
			throw new IllegalArgumentException();
		}else{
			Node temp = root;
			while(temp != null){
				int comp = key.compareTo(temp.key);
				if(comp == 0){
					return temp.value;
				}else if(comp < 0){
					temp = temp.left;
				}else{
					temp = temp.right;
				}
			}
			throw new IllegalArgumentException();
		}
	}
	
	
	private int height(Node root){
		if(count != 0){
			flush();
		}
		if(root == null){
			return 0;
		}else{
			int left = height(root.left);
			int right = height(root.right);
			int temp = (left > right)? left:right;
			return temp + 1;
		}
	}
	public int height(){
		return height(root);
	}
	
	public void put(String key, Value value){
		if(key == null){
			throw new IllegalArgumentException();
		}
		if(count == keys.length){
			flush();
		}
		keys[count] = key;
		values[count] = value;
		count++;	
	}
	private void putting(String key, Value value){
		if(root == null){
			root = new Node(key, value, null, null);
		}else{
			Node temp = root;
			while(true){
				if(key.compareTo(temp.key) < 0){ // left
					if(temp.left == null){
						temp.left = new Node(key, value, null, null);
						return;
					}else{
						temp = temp.left;
					}
				}else if(key.compareTo(temp.key) > 0){
					if(temp.right == null){
						temp.right = new Node(key, value, null, null);
						return;
					}else{
						temp = temp.right;
					}
				}else{ // key already existed.
					throw new IllegalStateException();
				}
			}
		}
	}
}