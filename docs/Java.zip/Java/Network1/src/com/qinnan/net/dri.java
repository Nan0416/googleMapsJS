package com.qinnan.net;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class dri {
	public static void main(String [] args) throws UnknownHostException{
		System.out.println(InetAddress.getLocalHost());
		InetSocketAddress addressGoal=new InetSocketAddress("192.168.56.1",8199);
		Socket connectS=new Socket();
		
		try{
			//Socket s=new Socket("www.google.com",80);
			connectS.connect(addressGoal, 10000);
			System.out.println(connectS.isConnected());
			
			InputStream netIn=connectS.getInputStream();
			Scanner consoleIn=new Scanner(netIn);
			int i=0;
			while(consoleIn.hasNextLine()){
				
				System.out.println((++i)+"th line "+consoleIn.nextLine());
			}
		}catch(IOException e){
			e.printStackTrace();
		}
		
	}

}
