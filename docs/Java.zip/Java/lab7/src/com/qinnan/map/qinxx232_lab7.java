package com.qinnan.map;
import java.lang.IllegalArgumentException;
public class qinxx232_lab7 {
	public static void main(String [] args){
		Map<String, Integer> numbers = new Map<String, Integer>(5,4);
		// autoboxing
		numbers.put("Zero", 0);
		numbers.put("One", 1);
		numbers.put("Two", 2);
		numbers.put("Three", 3);
		System.out.println(numbers.get("Two"));
		numbers.put("Two",-2);
		System.out.println(numbers.get("Two"));
		try{
			System.out.println(numbers.get("Four"));
		}catch(IllegalArgumentException e){
			System.out.println("Error");
		}
		numbers.put("Four", 4);
		numbers.put("Five", 5);
		numbers.put("Eigth",8);
		numbers.put("Seven", 7);
		numbers.put("Six", 6);
		System.out.println(numbers.get("Four") + " " + numbers.isIn("Nine"));
//		2
//		-2
//		Error
//		4 false

	}
}

class Map<Key, Value>{
	private Key[] keys;
	private Value[] values;
	private int count;
	private int increment;
	
	public Map(int length, int increment){
		if(length < 0 || increment <= 0){
			throw new IllegalArgumentException();
		}
		keys = (Key[]) new Object[length];
		values = (Value[]) new Object[length];
		this.increment = increment;
		count = 0;
	}
	
	public Map(){
		this(64, 8);
	}
	
	public Value get(Key key){
		int temp = where(key);
		if(temp == -1){
			throw new IllegalArgumentException();
		}
		return values[temp];
	}
	
	private boolean isEqual(Key leftKey, Key rightKey){
		return (leftKey == rightKey || leftKey.equals(rightKey));
	}
	
	public boolean isIn(Key key){
		return where(key) != -1;
	}
	
	public void put(Key key, Value value){
		int temp = where(key);
		if(temp != -1){
			values[temp] = value;
		}else{
			if(count == keys.length){
				Key[] temp_key = (Key[]) new Object[keys.length + increment];
				Value[] temp_value = (Value[]) new Object[values.length + increment];
				for(int i = 0; i < keys.length; i++){
					temp_key[i] = keys[i];
					temp_value[i] = values[i];
				}
				keys = temp_key;
				values = temp_value;
			}
			keys[count] = key;
			values[count] = value;
			count++;
		}
	}
	
	private int where(Key key){
		for(int i = 0; i < count; i++){
			if(isEqual(key, keys[i])){
				return i;
			}
		}
		return -1;
	}
	
} 
