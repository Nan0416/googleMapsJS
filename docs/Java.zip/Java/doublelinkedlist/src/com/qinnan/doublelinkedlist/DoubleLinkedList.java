package com.qinnan.doublelinkedlist;


import java.lang.IndexOutOfBoundsException;

public class DoubleLinkedList{
  
    private Element pointer;
    private int counter;
    private Element header;
    public DoubleLinkedList(Object... eles){
        Element temp = null;
        boolean flag = true;
        for(Object i : eles){
            counter ++;
            
            if (flag){
                header = temp = new Element(i);
                flag = false;
            }else{
                temp.linkNext(new Element(i));
                temp = temp.next();
                
            
            }
            pointer = temp;
        }
    }
    public Object get(int index){
        if (index < counter){
            int i=0;
            Element temp = header;
            while (i<index){
                temp = temp.next();
                i++;
            
            }
            return temp.getObject();
        }else{
            throw new IndexOutOfBoundsException();
        }
    
    }
    public void push(Object ele){
    	insert(counter,ele);
    }
    public void insert(int index, Object ele){
    	if(index < counter){
    		int i =0;
    		Element temp = header;
    		while(i< index){
    			temp = temp.next();
    			i++;
    		}
    		Element temp2= new Element(ele);
    		Element temp3 = temp.last;
    		if(temp3!=null){
    			temp3.linkNext(temp2);
    			temp2.linkNext(temp);
    		}else{
    			temp2.linkNext(temp);
    			this.header = temp2;
    			
    		}
    		this.counter++;
    		
    	}else if(index == counter){ 
    		pointer.linkNext(new Element(ele));
    		pointer = pointer.next();
    		this.counter++;
    		
    	}else{
    		throw new IndexOutOfBoundsException();
    		
    	}
    }
    public void remove(int index){
    	if(index < counter){
    		int i =0;
    		Element temp = header;
    		while(i< index){
    			temp = temp.next();
    			i++;
    		}
    		if(temp.last == null){
    			header = temp.next;
    			temp = null;
    		}else if(temp.next == null){
    			pointer = temp.last;
    			temp = null;
    		}else{
    			temp.last.linkNext(temp.next);
    			temp = null;
    		}
    		this.counter--;
    		
    	}else{
    		throw new IndexOutOfBoundsException();
    		
    	}
    	
    	
    }
    public int length(){
    	return counter;
    	
    }
    public void replace(int index, Object ele){
    	if(index < counter){
    		int i =0;
    		Element temp = header;
    		while(i< index){
    			temp = temp.next();
    			i++;
    		}
    		temp.relpace(ele);
    	}else{
    		throw new IndexOutOfBoundsException();
    		
    	}
    	
    }
    
    public Object pop(){
    	Element temp = pointer;
    	counter --;
    	pointer = temp.last;
    	return temp.ele;
    }
    
    public void showAll(){
    	Element temp = header;
    	
    	for(int i = 0; i< counter; i++){
    		System.out.print(temp.getObject() + " ");
    		temp = temp.next();
    		
    	}
    	
    }
    
    
    
    private class Element{
        private Object ele;
        private Element last = null;
        private Element next = null;
        public Element(Object ele){
            this.ele=ele;
        }
        public void linkNext(Element ob){
            this.next = ob;
            ob.last = this;
            
        }
        public Object getObject(){
            return ele;
        }
        
        public Element next(){
            return next;
        }
        public Element last(){
            return last;
        }
        public void relpace(Object ob){
        	this.ele = ob;
        }
    
    
    }



}