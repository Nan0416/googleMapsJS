package com.qinnan.doublelinkedlist;

public class Drive {
	public static void main(String [] args){
		DoubleLinkedList temp =new DoubleLinkedList("qin","nan","is","a","good","man");
		temp.showAll();
		temp.replace(4, "bad");
		System.out.println();
		temp.showAll();
		System.out.println();
		temp.insert(4, "absolutely");
		temp.showAll();
		temp.insert(0, "It is ridiculous that");
		System.out.println();
		temp.showAll();
		temp.insert(temp.length(), ".");
		System.out.println();
		temp.showAll();
		temp.replace(4,"an");
		temp.remove(0);
		temp.remove(temp.length()-1);
		temp.remove(5);
		
		System.out.println();
		temp.showAll();
		temp.pop();
		
		System.out.println();
		temp.showAll();
	}
}
