package com.qinnan.deadlock;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class dri {
	public static void main(String [] args){
		run r=new run();
		Thread t1=new Thread(r.run1());
		Thread t2=new Thread(r.run2());
		t1.start();
		t2.start();
		BlockingQueue<String> hu=new ArrayBlockingQueue<> (100);
	}
}
