package com.qinnan.deadlock;

import java.util.concurrent.locks.ReentrantLock;

public class run {
	private Thread t;
	private ReentrantLock lock;
	public run(){
		lock=new ReentrantLock();
	}
	
	public Runnable run1(){
		return new Runnable(){
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				lock.lock();
				try{
					t=Thread.currentThread();
					System.out.println("Something");
				}finally{
					lock.unlock();
				}
			}
		};
	}
	public Runnable run2(){
		return new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				t.suspend();
				lock.lock();
				try{
					System.out.println("Anything");
				}finally{
					lock.unlock();
				}
			}
			
			
		};
	}
}
